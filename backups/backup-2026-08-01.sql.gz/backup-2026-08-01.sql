--
-- PostgreSQL database dump
--

\restrict bTfehiHLmWZr2CXLEWrD5qFoO5IfqnbCWX5KaCWp3nViGhg2frB89X1dflu8GjU

-- Dumped from database version 18.4 (df16b3c)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CourtSurface; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CourtSurface" AS ENUM (
    'CLAY',
    'GRASS',
    'HARD'
);


--
-- Name: Gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE'
);


--
-- Name: MatchSide; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchSide" AS ENUM (
    'A',
    'B'
);


--
-- Name: MatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchStatus" AS ENUM (
    'SCHEDULED',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: MatchType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchType" AS ENUM (
    'SINGLES',
    'DOUBLES'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBER'
);


--
-- Name: TournamentFormat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentFormat" AS ENUM (
    'SINGLES',
    'DOUBLES',
    'MIXED'
);


--
-- Name: TournamentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentStatus" AS ENUM (
    'UPCOMING',
    'ONGOING',
    'COMPLETED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "actorId" text,
    "actorLabel" text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    summary text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: match_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_players (
    id text NOT NULL,
    "matchId" text NOT NULL,
    side public."MatchSide" NOT NULL,
    "playerId" text NOT NULL
);


--
-- Name: match_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_sets (
    id text NOT NULL,
    "matchId" text NOT NULL,
    "setNumber" integer NOT NULL,
    "sideAGames" integer NOT NULL,
    "sideBGames" integer NOT NULL,
    "tiebreakSideAPoints" integer,
    "tiebreakSideBPoints" integer
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    round text,
    "matchType" public."MatchType" NOT NULL,
    "scheduledDate" timestamp(3) without time zone,
    status public."MatchStatus" DEFAULT 'SCHEDULED'::public."MatchStatus" NOT NULL,
    "winnerSide" public."MatchSide",
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    retired boolean DEFAULT false NOT NULL
);


--
-- Name: news_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_posts (
    id text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gender public."Gender"
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: tournament_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_participants (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    "playerId" text NOT NULL,
    seed integer,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tournaments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    format public."TournamentFormat" NOT NULL,
    status public."TournamentStatus" DEFAULT 'UPCOMING'::public."TournamentStatus" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    surface public."CourtSurface" DEFAULT 'CLAY'::public."CourtSurface" NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    role public."Role" DEFAULT 'MEMBER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b6a4f99f-a8b6-4c06-85a9-4d39ff635363	f553e02dfb0e13179102a3d6a50b294e89fc66249f9020046762c435b7f90e80	2026-07-27 11:02:53.954768+00	20260727110248_init	\N	\N	2026-07-27 11:02:49.941974+00	1
799328ab-1eac-4efb-bbae-6bf65b4961b5	c7b4dda0637311e0d3ff7204537883b82173e06b1a8857d00afeb76e037b18a1	2026-07-27 13:46:12.42331+00	20260727134610_add_player_gender	\N	\N	2026-07-27 13:46:11.509481+00	1
66315c66-29d4-4095-ac76-7fe3013441c7	ae7461c9fc5e8e4dadcabdd436d8f0e8a5b479b756c9164d8a1c302355f611c2	2026-07-28 06:02:57.786793+00	20260728060256_add_news_posts	\N	\N	2026-07-28 06:02:57.031249+00	1
2dfe2022-3b79-4980-a314-86665a3e4e98	66a25451567a67f105fa46bc65c4172f8b855e0896697778a559e03935a6b194	2026-07-28 06:17:37.333148+00	20260728061735_add_tournament_surface	\N	\N	2026-07-28 06:17:36.237221+00	1
20a897a3-d0ba-455c-8b98-d3f36e3515d7	eae60b8cd55c17585d7781a1a3ee65756f2e2273db1aaa416ebf80c487a642fb	2026-07-28 06:24:09.571991+00	20260728062408_default_surface_to_clay	\N	\N	2026-07-28 06:24:08.684057+00	1
d63a7a98-c4a1-43bc-91a5-ecb3d4175c04	4921d79bd23cf610ac7c5704cc05ca2d67e0929ed90d66328ba18d4e47db693b	2026-07-31 11:57:25.22011+00	20260728070000_add_performance_indexes	\N	\N	2026-07-31 11:57:23.987974+00	1
2b044d39-8e83-458a-a629-4952bc3fbdd9	09bba3cb5f2c2de94d791c3a6025bdff1df0625b4ea75d3ed07777876d7eb345	2026-07-31 11:57:39.213879+00	20260731115737_add_tiebreak_score_and_retired	\N	\N	2026-07-31 11:57:38.340392+00	1
367198c0-2c3d-499a-b248-86403705ecc1	aeae99843ece00f28dcee192ce30a2214982fdc119747aed28c06a952b56b631	2026-07-31 12:25:39.804876+00	20260731122458_split_tiebreak_score	\N	\N	2026-07-31 12:25:38.058557+00	1
4c35128f-ef74-41b5-853e-2e8b34290431	5457109f26f73aa6e8ca3c46242b8babe6cbc3c31136f82cec2dbeeff654e49c	2026-07-31 12:49:14.258361+00	20260731124850_add_audit_log	\N	\N	2026-07-31 12:49:13.072346+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts ("userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
cms352tfv0000e0tdmfc0urb6	oidc	google	101751805477113985549	\N	ya29.a0ARGnu0YRk5ColLBpT3FpMxPrdj_gtcCtPNeI6WVbnNgS43z9mOeRIBKb7FsJ_Imke6bLdkXuXRHYCQVXhpE_oR4TtLw7ST8wnAWMkvqj010sAgyxMUY0zQxrZDClifeOVogOIiZZ8oGNO3d8bRLUXaNYcFWzvqaDW1sXRM3xkDwbAKDTk-_hGtAbTkGpzAxEwSHdN7IaCgYKAbwSARQSFQHGX2Mi_5LX2G3ozGMTtMchGKYS8g0206	1785155041	bearer	https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDE3NTE4MDU0NzcxMTM5ODU1NDkiLCJlbWFpbCI6InNkYWxpbjc3N0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6InZQcGt2a3JUTHlKajYtWUhjZ1ozVGciLCJuYW1lIjoiU2VyaGlpIEhpbGNoZW5rbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMY2Z1YW5NaW85Vld5cUdmdS1ZYUdVenlaX05xYk1tbVlwMXdBYXZpR3NYSGUtM0VqUT1zOTYtYyIsImdpdmVuX25hbWUiOiJTZXJoaWkiLCJmYW1pbHlfbmFtZSI6IkhpbGNoZW5rbyIsImlhdCI6MTc4NTE1MTQ0MiwiZXhwIjoxNzg1MTU1MDQyfQ.nVIwR1ybmWjwKGlBnKYYrQQD6jFswKVBuP5gM04AOgrEpj0SpNNpRXSlwLV8Sk-OyhiTRC7UMo59SJJZol0Z6JNi8Krzw5LY6jP9Ih3tziJkxm_N2Zrhy6cfF9N0d9iMfOqd8EINAa6hdBNzlbg2gpnfS3K4YwRPxgGmSqSOGQ9W15WIg8jJNZAqw0CuUnShYNjoug-jANK6jM5lDjKtdjahoo-FFugdWXcHwiDLycXr6ocG7ERGSwtPvQB5h058XlpU3CEoONq95hRSQCdc47iEheMTAvh_4RumNhzYgr5lBFC-m9dyUyiHaGLYb6C3aNb-DQdZEdZPElYdbN0YFQ	\N
cms37qbcp000004jldlm5roy0	oidc	google	100352920718100813505	\N	ya29.a0ARGnu0YMtGWrww8zyMopkaAnq-3iPaPjyxo4JQ4hJ9ASGhxHQ7ftjkafyzuCwa7EG2D3wHXpTTQJUm7yBnNe47VrDyqA0TSyPB9LR8G3zzT50D-z7kvhCvfn5XoM_cKcY3Z_4wRUOrYaSB0TqXxsKsctmZ5-9PXNDI4CCowWdudBXk49_3BBzOluObPZPhTn1MzJfzUaCgYKAfcSARcSFQHGX2Mi2TglX0TCH3tDvaymIA_K-A0206	1785159497	bearer	https://www.googleapis.com/auth/userinfo.email openid https://www.googleapis.com/auth/userinfo.profile	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDAzNTI5MjA3MTgxMDA4MTM1MDUiLCJlbWFpbCI6Im1rb3JvYm9rMDdAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJoQ3hTUUFaNzdpQXlFSGNxRHlYLWN3IiwibmFtZSI6Ik1hcmdvdCIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NKUFN6WEZjZzZoZEhxbDVHZmpWcHpvZ2JoWjdzdk5HYXBjMG56YU1pdkcwYzhpRmc9czk2LWMiLCJnaXZlbl9uYW1lIjoiTWFyZ290IiwiaWF0IjoxNzg1MTU1ODk4LCJleHAiOjE3ODUxNTk0OTh9.lW9mGIQUl2RNf8zzFJhyOKKy7HJH1sT8W3djk5-86rDrcYe_ethUKgsNZio3o53kYDyRlKJ05qNBdP-j_zoYh4MkxHpGdNiDFIwz1bKZCd-BVSsow-WtTfxpsxif35mdZvpWqwCHaUdbVJufv820VAM0UHy6goxrCFfua_KG8PjVSMn1lAmC9Gf19BfP5r00g97--978HGqZvcsZ_rboPc1BKNRIZm6UI50tLWoItouhML2zsrPA6btLNdXcfO9AINWVDP-EGocUtBKcTHi-YW340tq9dO0whkEDbsNf-7cwnHsPlIYetWU_HjtzxlyP0H4GzEjIsvnQjUqhdgKlNw	\N
cms7jjux1000004ldbqqk9i7v	oidc	google	100729604216933037533	\N	ya29.a0ARGnu0ZZMu6BB96C5s5PQ-L105Ety1VvC4bFDljMppUaYCaXCMp4bgGe7mE7ddDCYPhspp4mwgWq7qy-hBoZOTgbDlv1cnKhcdIiC6g069kcgLGzq8NZ0a5HPVCXszUecINxroLc5IEbUEuZVQ5XbvEER28q2zDCPCPPhjpEiWnYNGrYIWyz4jkXU_DJf8yCUq_cC2saCgYKAbQSARESFQHGX2MikXp4MLQmV_HWDynQoJafHQ0206	1785421215	bearer	https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email	eyJhbGciOiJSUzI1NiIsImtpZCI6ImI2ZGQ1MWU2NmQzNjAxMGJkM2JiZGZiM2M5MWExYTVmNmVjNmMxMmMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA3Mjk2MDQyMTY5MzMwMzc1MzMiLCJlbWFpbCI6ImRlbmkyMjA1ODVAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJUYWstVDNFaUVucldFd3RiXzJlb01RIiwibmFtZSI6ItCU0LXQvdC40YEg0JjQvtCz0LDQvdC-0LIiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jSkxVMzhnVGxKbGo4TmxsTXlLUmd6X0F3d0hWcTh0QmpmN3JiM2xMNUtZN2RLXzUzUnE9czk2LWMiLCJnaXZlbl9uYW1lIjoi0JTQtdC90LjRgSIsImZhbWlseV9uYW1lIjoi0JjQvtCz0LDQvdC-0LIiLCJpYXQiOjE3ODU0MTc2MTYsImV4cCI6MTc4NTQyMTIxNn0.327j34ixVUgBVFMTZaDiz9R-35lS0aGubDOXxMv7-CGMn76LF09VOPtv5zEsxkwXAIwH55rj-9a49FhY5slsYjgpBKTHXhzqO1JtXqkFnWBoWVYciFiyNxKOsuOYMYUJ1YX0LRVkLgcy-Ua8qGO_8SM4rjwPU70rZvlR_dVrRBR7PQB9j3NLfTOkoC6Jx0S1iTGclh_9JOf1JcMmZHk_g1eoK8BkQXK48ADbFeAWfK4zgkLIIq1tCu_-Wrd9lhVzRjQ7_kQRbhRcgR0guoHOuhqo_GqgBiICDcuL6-ks1UWCBIKt8x-GilYilW26fQGjH88fvsgTeU00SF73P5P1VA	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "actorId", "actorLabel", action, "entityType", "entityId", summary, "createdAt") FROM stdin;
cms8y7ls70002ywtdzd0k2b0x	\N	E2E Admin	player.create	Player	cms8y7llq0001ywtdo0frl2vj	Створено гравця "Playwright Explore Player 1785502702833"	2026-07-31 12:58:26.695
cms8y7oia0004ywtdg5w55gz7	\N	E2E Admin	tournament.create	Tournament	cms8y7oed0003ywtdujoew71l	Створено турнір "Playwright Explore Cup 1785502708467"	2026-07-31 12:58:30.226
cms8y9pi00007ywtdygt4ch42	\N	E2E Admin	player.create	Player	cms8y9pex0006ywtd571lpq6w	Створено гравця "Playwright Match Flow A 1785502799406"	2026-07-31 13:00:04.824
cms8y9rcu0009ywtd7tf8fkkm	\N	E2E Admin	player.create	Player	cms8y9r990008ywtd1p2219yo	Створено гравця "Playwright Match Flow B 1785502799406"	2026-07-31 13:00:07.23
cms8y9u2s000bywtdo0xe2hik	\N	E2E Admin	tournament.create	Tournament	cms8y9ty3000aywtdv3xvju2s	Створено турнір "Playwright Match Flow Cup 1785502799406"	2026-07-31 13:00:10.756
cms8yb10o000eywtdgmhjreqo	\N	E2E Admin	player.create	Player	cms8yb0ta000dywtdw3196ij5	Створено гравця "Playwright Match Flow A 1785502862988"	2026-07-31 13:01:06.408
cms8yb2ju000gywtdhvw1l7o7	\N	E2E Admin	player.create	Player	cms8yb2g4000fywtdxb8kwl1g	Створено гравця "Playwright Match Flow B 1785502862988"	2026-07-31 13:01:08.394
cms8yb58b000iywtdjv4krtkk	\N	E2E Admin	tournament.create	Tournament	cms8yb52c000hywtd4sz49fuo	Створено турнір "Playwright Match Flow Cup 1785502862988"	2026-07-31 13:01:11.867
cms8ybnm4000lywtdys6977n2	\N	E2E Admin	player.create	Player	cms8ybng4000kywtdqqukd8um	Створено гравця "Playwright Match Flow A 1785502892024"	2026-07-31 13:01:35.693
cms8ybpr3000nywtdfo9cb3cm	\N	E2E Admin	player.create	Player	cms8ybpjt000mywtd33jtqbch	Створено гравця "Playwright Match Flow B 1785502892024"	2026-07-31 13:01:38.463
cms8ybt4n000pywtdqr9s207t	\N	E2E Admin	tournament.create	Tournament	cms8ybsxm000oywtdu13yn56r	Створено турнір "Playwright Match Flow Cup 1785502892024"	2026-07-31 13:01:42.839
cms8ydke4000sywtdq7ulr0tw	\N	E2E Admin	player.create	Player	cms8ydkak000rywtde21mofgk	Створено гравця "Playwright Match Flow A 1785502981031"	2026-07-31 13:03:04.828
cms8ydm7j000uywtdskjv0ttb	\N	E2E Admin	player.create	Player	cms8ydm35000tywtd8p9c77c4	Створено гравця "Playwright Match Flow B 1785502981031"	2026-07-31 13:03:07.183
cms8ydp2a000wywtd2zgk56qu	\N	E2E Admin	tournament.create	Tournament	cms8ydoxt000vywtdilc4mu80	Створено турнір "Playwright Match Flow Cup 1785502981031"	2026-07-31 13:03:10.883
cms8ygcog000zywtd9dcahz68	\N	E2E Admin	player.create	Player	cms8ygch0000yywtdk15r8c90	Створено гравця "Playwright Match Flow A 1785503111656"	2026-07-31 13:05:14.8
cms8ygefk0011ywtdnpxcee5q	\N	E2E Admin	player.create	Player	cms8yge8l0010ywtd7nzaxavw	Створено гравця "Playwright Match Flow B 1785503111656"	2026-07-31 13:05:17.072
cms8yggxb0013ywtdy9g1dset	\N	E2E Admin	tournament.create	Tournament	cms8yggsk0012ywtdku486elx	Створено турнір "Playwright Match Flow Cup 1785503111656"	2026-07-31 13:05:20.303
cms8yhuie0016ywtdsq0hvxcg	\N	E2E Admin	player.create	Player	cms8yhudm0015ywtduyfczjxv	Створено гравця "Playwright Match Flow A 1785503181370"	2026-07-31 13:06:24.566
cms8yhx190018ywtdbp7v325m	\N	E2E Admin	tournament.create	Tournament	cms8yhwwp0017ywtdkjwstahv	Створено турнір "Playwright Match Flow Cup 1785503181370"	2026-07-31 13:06:27.837
cms8yj00r001bywtd2tl6zia3	\N	E2E Admin	player.create	Player	cms8yizwe001aywtdn3notvu3	Створено гравця "Playwright Match Flow A 1785503235229"	2026-07-31 13:07:18.363
cms8yj2cs001dywtd9w5zvvxc	\N	E2E Admin	tournament.create	Tournament	cms8yj27f001cywtdmfq90i1c	Створено турнір "Playwright Match Flow Cup 1785503235229"	2026-07-31 13:07:21.388
cms8ym76e001gywtdcvulsxfl	\N	E2E Admin	player.create	Player	cms8ym6wd001fywtdkywgohcn	Створено гравця "Playwright Match Flow A 1785503382462"	2026-07-31 13:09:47.606
cms8ym9bo001iywtdqys9muhf	\N	E2E Admin	player.create	Player	cms8ym977001hywtd39iejpih	Створено гравця "Playwright Match Flow B 1785503382462"	2026-07-31 13:09:50.388
cms8ymceg001kywtd8r0w8ezm	\N	E2E Admin	tournament.create	Tournament	cms8ymc9x001jywtdyqxy5bn9	Створено турнір "Playwright Match Flow Cup 1785503382462"	2026-07-31 13:09:54.377
cms8yosqk001pywtdioeazz7c	\N	E2E Admin	player.create	Player	cms8yosl9001oywtdmoc1owjf	Створено гравця "Playwright Match Flow A 1785503505059"	2026-07-31 13:11:48.86
cms8youtw001rywtdvx86gzdk	\N	E2E Admin	player.create	Player	cms8youo8001qywtd27tx5745	Створено гравця "Playwright Match Flow B 1785503505059"	2026-07-31 13:11:51.572
cms8yoxq9001tywtdnzxjq4je	\N	E2E Admin	tournament.create	Tournament	cms8yoxm7001sywtdcshq8lqk	Створено турнір "Playwright Match Flow Cup 1785503505059"	2026-07-31 13:11:55.329
cms8yr4k5001xywtdpymufz86	\N	E2E Admin	player.create	Player	cms8yr4cs001wywtdr8mp6v36	Створено гравця "Playwright Match Flow A 1785503614078"	2026-07-31 13:13:37.493
cms8yr643001zywtddgv7n8ul	\N	E2E Admin	player.create	Player	cms8yr61p001yywtdqsl0j8ow	Створено гравця "Playwright Match Flow B 1785503614078"	2026-07-31 13:13:39.507
cms8yr8f70021ywtdtcgczh2h	\N	E2E Admin	tournament.create	Tournament	cms8yr8a30020ywtdhrv5jw2s	Створено турнір "Playwright Match Flow Cup 1785503614078"	2026-07-31 13:13:42.499
cms8yt8e7002jywtde3n8wy3x	\N	E2E Admin	player.create	Player	cms8yt8a0002iywtd84cu8po3	Створено гравця "Playwright Match Flow B 1785503709837"	2026-07-31 13:15:15.775
cms8yrdgr0024ywtd4ne70lyd	\N	E2E Admin	tournament.participant.add	Tournament	cms8yr8a30020ywtdhrv5jw2s	Додано 2 учасник(ів) до турніру	2026-07-31 13:13:49.035
cms8ysb750027ywtdglzd50r6	\N	E2E Admin	player.create	Player	cms8ysb1c0026ywtdcvw3874h	Створено гравця "Playwright Match Flow A 1785503669641"	2026-07-31 13:14:32.753
cms8ysdb80029ywtdll9d0ezn	\N	E2E Admin	player.create	Player	cms8ysd6q0028ywtd01pyv6ue	Створено гравця "Playwright Match Flow B 1785503669641"	2026-07-31 13:14:35.492
cms8ysg4i002bywtdr4dsfa8a	\N	E2E Admin	tournament.create	Tournament	cms8ysfz9002aywtd8spwo8p6	Створено турнір "Playwright Match Flow Cup 1785503669641"	2026-07-31 13:14:39.138
cms8yslrv002eywtdx0jhcmw7	\N	E2E Admin	tournament.participant.add	Tournament	cms8ysfz9002aywtd8spwo8p6	Додано 2 учасник(ів) до турніру	2026-07-31 13:14:46.459
cms8yt6db002hywtdnm3ipd3h	\N	E2E Admin	player.create	Player	cms8yt68i002gywtd5laor613	Створено гравця "Playwright Match Flow A 1785503709837"	2026-07-31 13:15:13.151
cms8ytba5002lywtd6d2rucqe	\N	E2E Admin	tournament.create	Tournament	cms8ytb41002kywtdaoam0yrh	Створено турнір "Playwright Match Flow Cup 1785503709837"	2026-07-31 13:15:19.517
cms8ytg9y002oywtdi724go6s	\N	E2E Admin	tournament.participant.add	Tournament	cms8ytb41002kywtdaoam0yrh	Додано 2 учасник(ів) до турніру	2026-07-31 13:15:25.99
cms8yu29c002rywtdl80cvthb	\N	E2E Admin	player.create	Player	cms8yu26b002qywtdeggwcjrv	Створено гравця "Playwright Match Flow A 1785503751276"	2026-07-31 13:15:54.48
cms8yu448002tywtdo2thix9h	\N	E2E Admin	player.create	Player	cms8yu3xf002sywtdu8di940x	Створено гравця "Playwright Match Flow B 1785503751276"	2026-07-31 13:15:56.888
cms8yu6sv002vywtdsxwzbaqx	\N	E2E Admin	tournament.create	Tournament	cms8yu6oh002uywtdggggbf6w	Створено турнір "Playwright Match Flow Cup 1785503751276"	2026-07-31 13:16:00.367
cms8yua9b002yywtdnpv7ps85	\N	E2E Admin	tournament.participant.add	Tournament	cms8yu6oh002uywtdggggbf6w	Додано 2 учасник(ів) до турніру	2026-07-31 13:16:04.847
cms8yvkw70031ywtdzjmpn4u9	\N	E2E Admin	player.create	Player	cms8yvkp80030ywtdn0skcd0k	Створено гравця "Playwright Match Flow A 1785503821639"	2026-07-31 13:17:05.287
cms8yvmz40033ywtdyob5ry0a	\N	E2E Admin	player.create	Player	cms8yvmvu0032ywtdigekqmn5	Створено гравця "Playwright Match Flow B 1785503821639"	2026-07-31 13:17:07.984
cms8yvpzu0035ywtdidvih4qx	\N	E2E Admin	tournament.create	Tournament	cms8yvpsk0034ywtd1hqb0g5p	Створено турнір "Playwright Match Flow Cup 1785503821639"	2026-07-31 13:17:11.898
cms8yvu250038ywtdx8qtcjq4	\N	E2E Admin	tournament.participant.add	Tournament	cms8yvpsk0034ywtd1hqb0g5p	Додано 2 учасник(ів) до турніру	2026-07-31 13:17:17.165
cms8yzieh0002n8td56nkeh18	\N	E2E Admin	player.create	Player	cms8yzi6w0001n8tdr322ks02	Створено гравця "Playwright Match Flow A 1785504000973"	2026-07-31 13:20:08.681
cms8yzkcy0004n8td9ke67xgx	\N	E2E Admin	player.create	Player	cms8yzk6o0003n8td8rvaj0ct	Створено гравця "Playwright Match Flow B 1785504000973"	2026-07-31 13:20:11.218
cms8yzokc0006n8td9silno1w	\N	E2E Admin	tournament.create	Tournament	cms8yzogt0005n8tdkh3d0j35	Створено турнір "Playwright Match Flow Cup 1785504000973"	2026-07-31 13:20:16.668
cms8z14kf000an8tdcm0digx2	\N	E2E Admin	player.create	Player	cms8z14eb0009n8tdk4xz79sz	Створено гравця "Playwright Match Flow A 1785504079656"	2026-07-31 13:21:24.063
cms8z17pi000cn8tdfr1d33n1	\N	E2E Admin	tournament.create	Tournament	cms8z17l7000bn8tdqtgl283v	Створено турнір "Playwright Match Flow Cup 1785504079656"	2026-07-31 13:21:28.134
cms8z1b9k000en8tda1o3qc6h	\N	E2E Admin	tournament.participant.add	Tournament	cms8z17l7000bn8tdqtgl283v	Додано 1 учасник(ів) до турніру	2026-07-31 13:21:32.744
cms8z4pcv000hn8tdehp57wgw	\N	E2E Admin	player.create	Player	cms8z4p8z000gn8tdnzvnoydy	Створено гравця "Playwright Match Flow A 1785504249280"	2026-07-31 13:24:10.975
cms8z5gc9000kn8td1wrbuw1i	\N	E2E Admin	player.create	Player	cms8z5g50000jn8tde04klv1c	Створено гравця "Playwright Match Flow A 1785504284646"	2026-07-31 13:24:45.945
cms8z6fzl000nn8tdmnj2a943	\N	E2E Admin	player.create	Player	cms8z6ftj000mn8tdtnttjo4x	Створено гравця "Playwright Match Flow A 1785504328951"	2026-07-31 13:25:32.145
cms8z6j6y000pn8tdgerjl2wa	\N	E2E Admin	tournament.create	Tournament	cms8z6j2v000on8tdrffjk6lw	Створено турнір "Playwright Match Flow Cup 1785504328951"	2026-07-31 13:25:36.298
cms8z6msw000rn8tdzisqzsg9	\N	E2E Admin	tournament.participant.add	Tournament	cms8z6j2v000on8tdrffjk6lw	Додано 1 учасник(ів) до турніру	2026-07-31 13:25:40.976
cms8z8xf6000un8tdypc3ffht	\N	E2E Admin	player.create	Player	cms8z8x8t000tn8tdnstbayez	Створено гравця "Playwright Match Flow A 1785504444617"	2026-07-31 13:27:28.05
cms8z90jc000wn8tdmadkr48z	\N	E2E Admin	player.create	Player	cms8z90c1000vn8tdoxy7hpyp	Створено гравця "Playwright Match Flow B 1785504444617"	2026-07-31 13:27:32.088
cms8z9w4i000zn8td6erjtk6o	\N	E2E Admin	player.create	Player	cms8z9vwo000yn8td2czuczbc	Створено гравця "Playwright Match Flow A 1785504489310"	2026-07-31 13:28:13.026
cms8z9y8l0011n8tdcc4a1kue	\N	E2E Admin	player.create	Player	cms8z9y2g0010n8td69viktww	Створено гравця "Playwright Match Flow B 1785504489310"	2026-07-31 13:28:15.765
cms8za1dv0013n8td5vngj7nb	\N	E2E Admin	tournament.create	Tournament	cms8za1870012n8tdfuw2dg1o	Створено турнір "Playwright Match Flow Cup 1785504489310"	2026-07-31 13:28:19.843
cms8za61b0016n8tdukn1338e	\N	E2E Admin	tournament.participant.add	Tournament	cms8za1870012n8tdfuw2dg1o	Додано 2 учасник(ів) до турніру	2026-07-31 13:28:25.871
cms8zaayw001bn8tdnd2r4zf9	\N	E2E Admin	match.create	Match	cms8zaajo0018n8td89mz3j3g	Створено матч (SINGLES) у турнірі cms8za1870012n8tdfuw2dg1o	2026-07-31 13:28:32.264
cms8zaglt001en8tdphtk37ac	\N	E2E Admin	match.score	Match	cms8zaajo0018n8td89mz3j3g	Збережено рахунок матчу	2026-07-31 13:28:39.569
cms8zalyf001in8tdz439wwm3	\N	E2E Admin	match.randomize	Tournament	cms8za1870012n8tdfuw2dg1o	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:28:46.503
cms8zb4c7001nn8td30um9awt	\N	E2E Admin	player.create	Player	cms8zb468001mn8tda4z5bpe3	Створено гравця "Playwright Player 1785504545958"	2026-07-31 13:29:10.327
cms8zbb1x001qn8tdl23excpf	\N	E2E Admin	tournament.create	Tournament	cms8zbazf001pn8tdcv0nw4sx	Створено турнір "Playwright Cup 1785504551984"	2026-07-31 13:29:19.029
cms8zbgqu001tn8tdf2acz6gl	\N	E2E Admin	player.create	Player	cms8zbgmp001sn8td1npdh49c	Створено гравця "Playwright Match Flow A 1785504562793"	2026-07-31 13:29:26.406
cms8zbinw001vn8td96hjr4c8	\N	E2E Admin	player.create	Player	cms8zbiir001un8tdsmc7jhm6	Створено гравця "Playwright Match Flow B 1785504562793"	2026-07-31 13:29:28.892
cms8zblx5001xn8tdog9yojqu	\N	E2E Admin	tournament.create	Tournament	cms8zbltl001wn8tdk1cofbfw	Створено турнір "Playwright Match Flow Cup 1785504562793"	2026-07-31 13:29:33.113
cms8zbr7h0020n8tdps36xaz2	\N	E2E Admin	tournament.participant.add	Tournament	cms8zbltl001wn8tdk1cofbfw	Додано 2 учасник(ів) до турніру	2026-07-31 13:29:39.965
cms8zbyt50025n8tdp5486nvp	\N	E2E Admin	match.create	Match	cms8zbxlw0022n8tdf2ijddg8	Створено матч (SINGLES) у турнірі cms8zbltl001wn8tdk1cofbfw	2026-07-31 13:29:49.817
cms8zc4040028n8tdkpuwwekx	\N	E2E Admin	match.score	Match	cms8zbxlw0022n8tdf2ijddg8	Збережено рахунок матчу	2026-07-31 13:29:56.548
cms8zcbq7002cn8tdfo6g95m6	\N	E2E Admin	match.randomize	Tournament	cms8zbltl001wn8tdk1cofbfw	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:30:06.559
cms8zsiqp0002ektdlxpdm99w	\N	E2E Admin	player.create	Player	cms8zshx60001ektdiwue4kjm	Створено гравця "Playwright Match Flow A 1785505355456"	2026-07-31 13:42:42.145
cms8zskjh0004ektdmz1s2r51	\N	E2E Admin	player.create	Player	cms8zsk150003ektdq9ub3uhd	Створено гравця "Playwright Match Flow B 1785505355456"	2026-07-31 13:42:44.477
cms8zspbb0006ektdahbza3gt	\N	E2E Admin	tournament.create	Tournament	cms8zsmyn0005ektdokp6r7cm	Створено турнір "Playwright Match Flow Cup 1785505355456"	2026-07-31 13:42:50.663
cms8zss8c0009ektdw17kck8i	\N	E2E Admin	tournament.participant.add	Tournament	cms8zsmyn0005ektdokp6r7cm	Додано 2 учасник(ів) до турніру	2026-07-31 13:42:54.444
cms8zszaf000eektd8tuq9ij2	\N	E2E Admin	match.create	Match	cms8zswba000bektdvuzx2x1z	Створено матч (SINGLES) у турнірі cms8zsmyn0005ektdokp6r7cm	2026-07-31 13:43:03.591
cms8zt4dh000hektdnq62egls	\N	E2E Admin	match.score	Match	cms8zswba000bektdvuzx2x1z	Збережено рахунок матчу	2026-07-31 13:43:10.181
cms8zt8ot000lektdwuq16yf9	\N	E2E Admin	match.randomize	Tournament	cms8zsmyn0005ektdokp6r7cm	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:43:15.774
cms8ztulr000oektduny9ixmy	\N	E2E Admin	player.create	Player	cms8ztu3s000nektdmy5nhg8x	Створено гравця "Playwright Match Flow A 1785505420734"	2026-07-31 13:43:44.175
cms8zty3n000qektdyd0yx8wm	\N	E2E Admin	tournament.create	Tournament	cms8ztwjx000pektdjcyplw0v	Створено турнір "Playwright Match Flow Cup 1785505420734"	2026-07-31 13:43:48.707
cms8zu0t2000sektdfuklljqn	\N	E2E Admin	tournament.participant.add	Tournament	cms8ztwjx000pektdjcyplw0v	Додано 1 учасник(ів) до турніру	2026-07-31 13:43:52.214
cms9bzm3q000104jlzbjwr53x	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.create	Tournament	cms9bzlta000004jljxxeodss	Створено турнір "Тест"	2026-07-31 19:24:08.486
cms9c09x4000c04l2a4xd33ts	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.add	Tournament	cms9bzlta000004jljxxeodss	Додано 12 учасник(ів) до турніру	2026-07-31 19:24:39.352
cms9c0h63000d04l2x6mcrkzl	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37in3h000004i8eoz8ipze	2026-07-31 19:24:48.747
cms9c0lku000204jljl2u96qg	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37zfzn0005hgtd7gza4cvn	2026-07-31 19:24:54.462
cms9c0n0g000004l71uv52voh	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms6henfo000004l6bztvhooq	2026-07-31 19:24:56.32
cms9c0nkj000104l7d2r9jjo6	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms66zpp4000004i916qdj51o	2026-07-31 19:24:57.043
cms9c0r5i000004kzcq51872h	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37hxxp000004kv12xpq61b	2026-07-31 19:25:01.686
cms9c0sow000104kz5u80dhzt	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms4if36v000004l8sq7n50wi	2026-07-31 19:25:03.68
cms9c1kuo001q04kzj8y0u1n0	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cms9bzlta000004jljxxeodss	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-07-31 19:25:40.176
cms9c2ctr000304l7zudvk8cm	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	2581d722-8cd1-42cb-bf64-538b322e70c3	Збережено рахунок матчу	2026-07-31 19:26:16.431
cms9c2tt7000504l7b39w7kkn	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	bcefca21-1aa8-4e87-9d24-08daf9f85d75	Збережено рахунок матчу	2026-07-31 19:26:38.443
cms9c32wj000604l7v0r2b2ph	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.delete	Tournament	cms9bzlta000004jljxxeodss	Видалено турнір "Тест"	2026-07-31 19:26:50.227
\.


--
-- Data for Name: match_players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_players (id, "matchId", side, "playerId") FROM stdin;
cms4j0mqu000104l4tomun2h5	cms4j0mo8000004l41m4cut27	A	cms37in3h000004i8eoz8ipze
cms4j0mqu000204l46n4dtppe	cms4j0mo8000004l41m4cut27	A	cms36j9tj000050tdrji7jgzy
cms4j0mqu000304l4aler6ppy	cms4j0mo8000004l41m4cut27	B	cms4if36v000004l8sq7n50wi
cms4j0mqu000404l4bhuw32x8	cms4j0mo8000004l41m4cut27	B	cms3808b20008hgtdaxtqowy3
cms4j4hu5000104jsaf7ftv32	cms4j4hrd000004jsmbpa99ge	A	cms37zyg50007hgtdu0buusvi
cms4j4hu5000204jszn7c08r7	cms4j4hrd000004jsmbpa99ge	A	cms37zki10006hgtd5877avlo
cms4j4hu5000304js9k8cl1wm	cms4j4hrd000004jsmbpa99ge	B	cms4ihelf000104jmwd1jh41x
cms4j4hu5000404jsjmxxxjb6	cms4j4hrd000004jsmbpa99ge	B	cms37zfzn0005hgtd7gza4cvn
cms4jbto6000104jimvd0kc87	cms4jbtlk000004ji4rrklq3q	A	cms36j9tj000050tdrji7jgzy
cms4jbto6000204jiwtfmkuf0	cms4jbtlk000004ji4rrklq3q	A	cms37in3h000004i8eoz8ipze
cms4jbto6000304ji9odsshif	cms4jbtlk000004ji4rrklq3q	B	cms37hxxp000004kv12xpq61b
cms4jbto6000404jix81i7vz9	cms4jbtlk000004ji4rrklq3q	B	cms4ifgek000004jm2hynvj8w
cms4jesm0000604jiqhqm6j0u	cms4jesjc000504jiywmobz2c	A	cms37hxxp000004kv12xpq61b
cms4jesm0000704jihc8rdeph	cms4jesjc000504jiywmobz2c	A	cms4ifgek000004jm2hynvj8w
cms4jesm0000804ji2zk40n7t	cms4jesjc000504jiywmobz2c	B	cms4if36v000004l8sq7n50wi
cms4jesm0000904jiv39prcgw	cms4jesjc000504jiywmobz2c	B	cms3808b20008hgtdaxtqowy3
cms4jhyo8000304laqyrz3uw2	cms4jhylk000204lajbn2pnu9	A	cms37zki10006hgtd5877avlo
cms4jhyo8000404la7jv89vso	cms4jhylk000204lajbn2pnu9	A	cms37zyg50007hgtdu0buusvi
cms4jhyo8000504la2irgn5bd	cms4jhylk000204lajbn2pnu9	B	cms36j9tj000050tdrji7jgzy
cms4jhyo8000604laobwdjqq9	cms4jhylk000204lajbn2pnu9	B	cms37in3h000004i8eoz8ipze
cms4k0osn000104jvoivkyr33	cms4k0opv000004jvoccgnrtk	A	cms37zfzn0005hgtd7gza4cvn
cms4k0osn000204jvfznf3l9v	cms4k0opv000004jvoccgnrtk	A	cms4ihelf000104jmwd1jh41x
cms4k0osn000304jvr427y3yx	cms4k0opv000004jvoccgnrtk	B	cms4if36v000004l8sq7n50wi
cms4k0osn000404jvb8x3tp1x	cms4k0opv000004jvoccgnrtk	B	cms3808b20008hgtdaxtqowy3
cms4k9a39000104jm5c2jf7oj	cms4k9a0m000004jmmy7x0e1c	A	cms37hxxp000004kv12xpq61b
cms4k9a39000204jmx77b8o4k	cms4k9a0m000004jmmy7x0e1c	A	cms4ifgek000004jm2hynvj8w
cms4k9a39000304jmoe2cjz95	cms4k9a0m000004jmmy7x0e1c	B	cms37zyg50007hgtdu0buusvi
cms4k9a39000404jmelankdn8	cms4k9a0m000004jmmy7x0e1c	B	cms37zki10006hgtd5877avlo
cms4kf9md000104jsinrhyf0g	cms4kf9jo000004jsil9npat8	A	cms37zfzn0005hgtd7gza4cvn
cms4kf9md000204js7cttjaz5	cms4kf9jo000004jsil9npat8	A	cms4ihelf000104jmwd1jh41x
cms4kf9md000304jsfmnqica9	cms4kf9jo000004jsil9npat8	B	cms37hxxp000004kv12xpq61b
cms4kf9md000404js3uw3oh1l	cms4kf9jo000004jsil9npat8	B	cms4ifgek000004jm2hynvj8w
cms4kijxc000104jvv8sh4erc	cms4kijup000004jvmyf3bp7f	A	cms37zki10006hgtd5877avlo
cms4kijxc000204jvl9z9ju8t	cms4kijup000004jvmyf3bp7f	A	cms37zyg50007hgtdu0buusvi
cms4kijxc000304jveniepzbq	cms4kijup000004jvmyf3bp7f	B	cms4if36v000004l8sq7n50wi
cms4kijxc000404jvg4resngz	cms4kijup000004jvmyf3bp7f	B	cms3808b20008hgtdaxtqowy3
cms4kjkx7000204jsbdbwbjdo	cms4kjkuk000104jsfpxtv5x8	A	cms37in3h000004i8eoz8ipze
cms4kjkx7000304jsw2zs17i2	cms4kjkuk000104jsfpxtv5x8	A	cms36j9tj000050tdrji7jgzy
cms4kjkx7000404jsjq1rw7cd	cms4kjkuk000104jsfpxtv5x8	B	cms4ihelf000104jmwd1jh41x
cms4kjkx7000504jsnefj7bz2	cms4kjkuk000104jsfpxtv5x8	B	cms37zfzn0005hgtd7gza4cvn
\.


--
-- Data for Name: match_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_sets (id, "matchId", "setNumber", "sideAGames", "sideBGames", "tiebreakSideAPoints", "tiebreakSideBPoints") FROM stdin;
cms4j11p2000504l4iyd578pn	cms4j0mo8000004l41m4cut27	1	6	4	\N	\N
cms4j7xxe000004laws91wx8d	cms4j4hrd000004jsmbpa99ge	1	4	6	\N	\N
cms4jc832000104lafz3w9h57	cms4jbtlk000004ji4rrklq3q	1	6	2	\N	\N
cms4jf7fz000a04jiwrlsqk88	cms4jesjc000504jiywmobz2c	1	6	3	\N	\N
cms4jiniq000b04jifp7fredt	cms4jhylk000204lajbn2pnu9	1	3	6	\N	\N
cms4k15dd000004layaefou1t	cms4k0opv000004jvoccgnrtk	1	7	5	\N	\N
cms4k9lyd000004ieb6pcieg2	cms4k9a0m000004jmmy7x0e1c	1	3	6	\N	\N
cms4kgb3j000004jslji94ypg	cms4kf9jo000004jsil9npat8	1	6	7	\N	\N
cms4kjycc000004l7w7sonp4f	cms4kjkuk000104jsfpxtv5x8	1	6	4	\N	\N
cms4kkemd000104l71mwf9zl0	cms4kijup000004jvmyf3bp7f	1	6	7	\N	\N
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, "tournamentId", round, "matchType", "scheduledDate", status, "winnerSide", "createdAt", "updatedAt", retired) FROM stdin;
cms4jesjc000504jiywmobz2c	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:53:03.096	2026-07-28 10:53:22.509	f
cms4jhylk000204lajbn2pnu9	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 10:55:30.92	2026-07-28 10:56:03.311	f
cms4k0opv000004jvoccgnrtk	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 11:10:04.579	2026-07-28 11:10:26.258	f
cms4k9a0m000004jmmy7x0e1c	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:16:45.43	2026-07-28 11:17:00.996	f
cms4j0mo8000004l41m4cut27	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:42:02.312	2026-07-28 10:42:21.901	f
cms4j4hrd000004jsmbpa99ge	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 10:45:02.569	2026-07-28 10:47:43.585	f
cms4jbtlk000004ji4rrklq3q	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:50:44.504	2026-07-28 10:51:03.373	f
cms4kf9jo000004jsil9npat8	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:21:24.756	2026-07-28 11:22:13.518	f
cms4kjkuk000104jsfpxtv5x8	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 11:24:46.028	2026-07-28 11:25:03.611	f
cms4kijup000004jvmyf3bp7f	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:23:58.081	2026-07-28 11:25:24.707	f
\.


--
-- Data for Name: news_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_posts (id, title, body, "authorId", "createdAt", "updatedAt") FROM stdin;
cms49hbv6000004lb1e5s98g6	Запуск сайту!	Це перша публікація, але не остання)	cms352tfv0000e0tdmfc0urb6	2026-07-28 06:15:05.298	2026-07-28 12:04:53.845
cms8p21a5000004kv2u266b2u	🎾 Парний турнір 2×2 вже цієї суботи!	Цієї суботи наш клуб стане ареною захопливих тенісних баталій — на вас чекає парний турнір 2×2! 💥\r\n\r\n🕘 Старт о 9:00\r\n\r\nПопереду — яскраві розіграші, напружені матчі, командна боротьба та море емоцій. Учасники вже готові виходити на корт, а ми запрошуємо всіх уболівальників підтримати своїх фаворитів і провести ранок у чудовій спортивній атмосфері.\r\n\r\nДо зустрічі на кортах! 🎾🙌	cms352tfv0000e0tdmfc0urb6	2026-07-31 08:42:10.301	2026-07-31 08:42:10.301
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, name, email, "userId", "createdAt", gender) FROM stdin;
cms36j9tj000050tdrji7jgzy	Гільченко Сергій	sdalin777@gmail.com	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:04:50.935	MALE
cms378xqi0001hgtdr6l6sxef	Короткова Маргарита	mkorobok07@gmail.com	cms37qbcp000004jldlm5roy0	2026-07-27 12:24:48.33	FEMALE
cms3808b20008hgtdaxtqowy3	Андрєєв Олександр	\N	\N	2026-07-27 12:46:01.742	MALE
cms37zyg50007hgtdu0buusvi	Данілюк Євген	\N	\N	2026-07-27 12:45:48.965	MALE
cms37zki10006hgtd5877avlo	Матушевська Олена	\N	\N	2026-07-27 12:45:30.889	FEMALE
cms37zfzn0005hgtd7gza4cvn	Матушевський Олег	\N	\N	2026-07-27 12:45:25.043	MALE
cms37hxxp000004kv12xpq61b	Демʼянішин Тарас	\N	\N	2026-07-27 12:31:48.493	MALE
cms4if36v000004l8sq7n50wi	Теребіж Віктор	\N	\N	2026-07-28 10:25:17.287	MALE
cms4ifgek000004jm2hynvj8w	Кулеш Ірина	\N	\N	2026-07-28 10:25:34.412	FEMALE
cms4ihelf000104jmwd1jh41x	Баранова Олександра	\N	\N	2026-07-28 10:27:05.379	FEMALE
cms66zpp4000004i916qdj51o	Хищенко Олександр	\N	\N	2026-07-29 14:40:56.536	MALE
cms6henfo000004l6bztvhooq	Терехов Ілля	\N	\N	2026-07-29 19:32:29.605	MALE
cms6hfgdv000004icc7dad5ve	Терехова Ганна	\N	\N	2026-07-29 19:33:07.123	FEMALE
cms37in3h000004i8eoz8ipze	Іоганов Денис	deni220585@gmail.com	cms7jjux1000004ldbqqk9i7v	2026-07-27 12:32:21.101	MALE
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions ("sessionToken", "userId", expires) FROM stdin;
a909d466-22e6-442e-9555-0cf7c3880e3e	cms352tfv0000e0tdmfc0urb6	2026-08-26 16:44:51.091
1eda930d-5ce8-4a3c-b235-ddab627e41a8	cms352tfv0000e0tdmfc0urb6	2026-08-30 07:09:32.146
874fa4f3-af9b-4483-b446-ca62baca9f62	cms352tfv0000e0tdmfc0urb6	2026-08-30 13:50:53.713
2f432af2-eb09-4f2d-b050-a0498d92880d	cms7jjux1000004ldbqqk9i7v	2026-08-30 18:30:30.615
728eca72-df97-4d9f-8515-8bc09ca2064f	cms37qbcp000004jldlm5roy0	2026-08-27 14:50:36.641
\.


--
-- Data for Name: tournament_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournament_participants (id, "tournamentId", "playerId", seed, "joinedAt") FROM stdin;
cms37f2qg0003hgtdh1afxqao	cms37eo8e0002hgtdbop2o98w	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 12:29:34.744
cms381l670009hgtd16ewm01w	cms37eo8e0002hgtdbop2o98w	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 12:47:05.071
cms381vpa000chgtdn8l54hlp	cms37eo8e0002hgtdbop2o98w	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 12:47:18.718
cms38ogf3000104l7utvevswm	cms38gx1f000004jnvhqe1ilw	cms37zki10006hgtd5877avlo	\N	2026-07-27 13:04:51.999
cms38oj4y000204js1on3helm	cms38gx1f000004jnvhqe1ilw	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 13:04:55.522
cms38oluz000004jyplksx1tv	cms38gx1f000004jnvhqe1ilw	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 13:04:59.051
cms38oqn2000304l74y5ktx01	cms38gx1f000004jnvhqe1ilw	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 13:05:05.246
cms4ilucf000004jj1ae99gtx	cms38gx1f000004jnvhqe1ilw	cms4ifgek000004jm2hynvj8w	\N	2026-07-28 10:30:32.415
cms6700lg000104i97q209ot9	cms38gx1f000004jnvhqe1ilw	cms66zpp4000004i916qdj51o	1	2026-07-29 14:41:10.66
cms6hg7vg000104l6elsxywxe	cms38gx1f000004jnvhqe1ilw	cms6henfo000004l6bztvhooq	1	2026-07-29 19:33:42.748
cms4iikhw000304jm5f0rz8qo	cms37eo8e0002hgtdbop2o98w	cms4ifgek000004jm2hynvj8w	\N	2026-07-28 10:27:59.684
cms4iikpr000404jma6rgjehm	cms37eo8e0002hgtdbop2o98w	cms4ihelf000104jmwd1jh41x	\N	2026-07-28 10:27:59.967
cms37kqdq000104i80lztwuup	cms37eo8e0002hgtdbop2o98w	cms37in3h000004i8eoz8ipze	1	2026-07-27 12:33:58.67
cms37ksui000104kvulzahp4m	cms37eo8e0002hgtdbop2o98w	cms37hxxp000004kv12xpq61b	1	2026-07-27 12:34:01.866
cms381qea000ahgtdk8yd75q7	cms37eo8e0002hgtdbop2o98w	cms37zfzn0005hgtd7gza4cvn	1	2026-07-27 12:47:11.842
cms381t7e000bhgtdl8imb9w8	cms37eo8e0002hgtdbop2o98w	cms37zki10006hgtd5877avlo	1	2026-07-27 12:47:15.483
cms4iik9u000204jms1mucsbh	cms37eo8e0002hgtdbop2o98w	cms4if36v000004l8sq7n50wi	1	2026-07-28 10:27:59.394
cms6hg83e000204l67d5xwwe1	cms38gx1f000004jnvhqe1ilw	cms6hfgdv000004icc7dad5ve	\N	2026-07-29 19:33:43.034
cms38oass000004jstg99u8xe	cms38gx1f000004jnvhqe1ilw	cms37in3h000004i8eoz8ipze	1	2026-07-27 13:04:44.716
cms38odmo000104jsx9nw55y5	cms38gx1f000004jnvhqe1ilw	cms37hxxp000004kv12xpq61b	1	2026-07-27 13:04:48.384
cms38ooh5000204l7b6447s1c	cms38gx1f000004jnvhqe1ilw	cms37zfzn0005hgtd7gza4cvn	1	2026-07-27 13:05:02.441
cms4ilukf000104jjkculx3ta	cms38gx1f000004jnvhqe1ilw	cms4if36v000004l8sq7n50wi	1	2026-07-28 10:30:32.703
\.


--
-- Data for Name: tournaments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournaments (id, name, description, format, status, "startDate", "endDate", "createdById", "createdAt", "updatedAt", surface) FROM stdin;
cms37eo8e0002hgtdbop2o98w	18.07.2026	Парний турнір за участю 5 команд	DOUBLES	COMPLETED	2026-07-18 00:00:00	2026-07-18 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:29:15.95	2026-07-28 10:43:37.049	CLAY
cms38gx1f000004jnvhqe1ilw	01.08.2026	\N	DOUBLES	UPCOMING	2026-08-01 00:00:00	2026-08-01 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:59:00.291	2026-07-30 09:36:08.202	CLAY
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, role, "createdAt") FROM stdin;
cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	sdalin777@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocLcfuanMio9VWyqGfu-YaGUzyZ_NqbMmmYp1wAaviGsXHe-3EjQ=s96-c	ADMIN	2026-07-27 11:24:03.595
cms37qbcp000004jldlm5roy0	Margot	mkorobok07@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJPSzXFcg6hdHql5GfjVpzogbhZ7svNGapc0nzaMivG0c8iFg=s96-c	MEMBER	2026-07-27 12:38:19.129
cms7jjux1000004ldbqqk9i7v	Денис Иоганов	deni220585@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJLU38gTlJlj8NllMyKRgz_AwwHVq8tBjf7rb3lL5KY7dK_53Rq=s96-c	ADMIN	2026-07-30 13:20:17.989
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (provider, "providerAccountId");


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: match_players match_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_pkey PRIMARY KEY (id);


--
-- Name: match_sets match_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT match_sets_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: news_posts news_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT news_posts_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: tournament_participants tournament_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT tournament_participants_pkey PRIMARY KEY (id);


--
-- Name: tournaments tournaments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (identifier, token);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: match_players_matchId_side_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_players_matchId_side_playerId_key" ON public.match_players USING btree ("matchId", side, "playerId");


--
-- Name: match_players_playerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "match_players_playerId_idx" ON public.match_players USING btree ("playerId");


--
-- Name: match_sets_matchId_setNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_sets_matchId_setNumber_key" ON public.match_sets USING btree ("matchId", "setNumber");


--
-- Name: matches_tournamentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matches_tournamentId_idx" ON public.matches USING btree ("tournamentId");


--
-- Name: players_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX players_email_key ON public.players USING btree (email);


--
-- Name: players_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "players_userId_key" ON public.players USING btree ("userId");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sessions_userId_idx" ON public.sessions USING btree ("userId");


--
-- Name: tournament_participants_playerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tournament_participants_playerId_idx" ON public.tournament_participants USING btree ("playerId");


--
-- Name: tournament_participants_tournamentId_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tournament_participants_tournamentId_playerId_key" ON public.tournament_participants USING btree ("tournamentId", "playerId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: match_players match_players_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_players match_players_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_sets match_sets_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT "match_sets_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matches matches_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT "matches_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_posts news_posts_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT "news_posts_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: players players_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT "players_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournaments tournaments_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT "tournaments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict bTfehiHLmWZr2CXLEWrD5qFoO5IfqnbCWX5KaCWp3nViGhg2frB89X1dflu8GjU

