--
-- PostgreSQL database dump
--

\restrict epGafom1Iwrf8DY5I3E2PluyQ7GXSXy0ALnvRdwWGIdva0mfWSKP4PNpV9B1m1Y

-- Dumped from database version 18.4 (df16b3c)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CourtSurface; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CourtSurface" AS ENUM (
    'CLAY',
    'GRASS',
    'HARD'
);


--
-- Name: Gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE'
);


--
-- Name: MatchSide; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchSide" AS ENUM (
    'A',
    'B'
);


--
-- Name: MatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchStatus" AS ENUM (
    'SCHEDULED',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: MatchType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchType" AS ENUM (
    'SINGLES',
    'DOUBLES'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBER'
);


--
-- Name: TournamentFormat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentFormat" AS ENUM (
    'SINGLES',
    'DOUBLES',
    'MIXED'
);


--
-- Name: TournamentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentStatus" AS ENUM (
    'UPCOMING',
    'ONGOING',
    'COMPLETED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "actorId" text,
    "actorLabel" text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    summary text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: match_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_players (
    id text NOT NULL,
    "matchId" text NOT NULL,
    side public."MatchSide" NOT NULL,
    "playerId" text NOT NULL
);


--
-- Name: match_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_sets (
    id text NOT NULL,
    "matchId" text NOT NULL,
    "setNumber" integer NOT NULL,
    "sideAGames" integer NOT NULL,
    "sideBGames" integer NOT NULL,
    "tiebreakSideAPoints" integer,
    "tiebreakSideBPoints" integer
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    round text,
    "matchType" public."MatchType" NOT NULL,
    "scheduledDate" timestamp(3) without time zone,
    status public."MatchStatus" DEFAULT 'SCHEDULED'::public."MatchStatus" NOT NULL,
    "winnerSide" public."MatchSide",
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    retired boolean DEFAULT false NOT NULL,
    "completedAt" timestamp(3) without time zone
);


--
-- Name: news_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_posts (
    id text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gender public."Gender"
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: tournament_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_participants (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    "playerId" text NOT NULL,
    seed integer,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tournaments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    format public."TournamentFormat" NOT NULL,
    status public."TournamentStatus" DEFAULT 'UPCOMING'::public."TournamentStatus" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    surface public."CourtSurface" DEFAULT 'CLAY'::public."CourtSurface" NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    role public."Role" DEFAULT 'MEMBER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b6a4f99f-a8b6-4c06-85a9-4d39ff635363	f553e02dfb0e13179102a3d6a50b294e89fc66249f9020046762c435b7f90e80	2026-07-27 11:02:53.954768+00	20260727110248_init	\N	\N	2026-07-27 11:02:49.941974+00	1
799328ab-1eac-4efb-bbae-6bf65b4961b5	c7b4dda0637311e0d3ff7204537883b82173e06b1a8857d00afeb76e037b18a1	2026-07-27 13:46:12.42331+00	20260727134610_add_player_gender	\N	\N	2026-07-27 13:46:11.509481+00	1
66315c66-29d4-4095-ac76-7fe3013441c7	ae7461c9fc5e8e4dadcabdd436d8f0e8a5b479b756c9164d8a1c302355f611c2	2026-07-28 06:02:57.786793+00	20260728060256_add_news_posts	\N	\N	2026-07-28 06:02:57.031249+00	1
2dfe2022-3b79-4980-a314-86665a3e4e98	66a25451567a67f105fa46bc65c4172f8b855e0896697778a559e03935a6b194	2026-07-28 06:17:37.333148+00	20260728061735_add_tournament_surface	\N	\N	2026-07-28 06:17:36.237221+00	1
20a897a3-d0ba-455c-8b98-d3f36e3515d7	eae60b8cd55c17585d7781a1a3ee65756f2e2273db1aaa416ebf80c487a642fb	2026-07-28 06:24:09.571991+00	20260728062408_default_surface_to_clay	\N	\N	2026-07-28 06:24:08.684057+00	1
d63a7a98-c4a1-43bc-91a5-ecb3d4175c04	4921d79bd23cf610ac7c5704cc05ca2d67e0929ed90d66328ba18d4e47db693b	2026-07-31 11:57:25.22011+00	20260728070000_add_performance_indexes	\N	\N	2026-07-31 11:57:23.987974+00	1
2b044d39-8e83-458a-a629-4952bc3fbdd9	09bba3cb5f2c2de94d791c3a6025bdff1df0625b4ea75d3ed07777876d7eb345	2026-07-31 11:57:39.213879+00	20260731115737_add_tiebreak_score_and_retired	\N	\N	2026-07-31 11:57:38.340392+00	1
367198c0-2c3d-499a-b248-86403705ecc1	aeae99843ece00f28dcee192ce30a2214982fdc119747aed28c06a952b56b631	2026-07-31 12:25:39.804876+00	20260731122458_split_tiebreak_score	\N	\N	2026-07-31 12:25:38.058557+00	1
4c35128f-ef74-41b5-853e-2e8b34290431	5457109f26f73aa6e8ca3c46242b8babe6cbc3c31136f82cec2dbeeff654e49c	2026-07-31 12:49:14.258361+00	20260731124850_add_audit_log	\N	\N	2026-07-31 12:49:13.072346+00	1
6159e531-92f4-46d3-916b-c60b10ef8c82	d6784e883de32b5668e750e042fee9471bde38fbd5f077023f8dcc85e0854fae	2026-08-01 13:11:57.368172+00	20260801131156_add_match_completed_at	\N	\N	2026-08-01 13:11:57.014097+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts ("userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
cms352tfv0000e0tdmfc0urb6	oidc	google	101751805477113985549	\N	ya29.a0ARGnu0YRk5ColLBpT3FpMxPrdj_gtcCtPNeI6WVbnNgS43z9mOeRIBKb7FsJ_Imke6bLdkXuXRHYCQVXhpE_oR4TtLw7ST8wnAWMkvqj010sAgyxMUY0zQxrZDClifeOVogOIiZZ8oGNO3d8bRLUXaNYcFWzvqaDW1sXRM3xkDwbAKDTk-_hGtAbTkGpzAxEwSHdN7IaCgYKAbwSARQSFQHGX2Mi_5LX2G3ozGMTtMchGKYS8g0206	1785155041	bearer	https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDE3NTE4MDU0NzcxMTM5ODU1NDkiLCJlbWFpbCI6InNkYWxpbjc3N0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6InZQcGt2a3JUTHlKajYtWUhjZ1ozVGciLCJuYW1lIjoiU2VyaGlpIEhpbGNoZW5rbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMY2Z1YW5NaW85Vld5cUdmdS1ZYUdVenlaX05xYk1tbVlwMXdBYXZpR3NYSGUtM0VqUT1zOTYtYyIsImdpdmVuX25hbWUiOiJTZXJoaWkiLCJmYW1pbHlfbmFtZSI6IkhpbGNoZW5rbyIsImlhdCI6MTc4NTE1MTQ0MiwiZXhwIjoxNzg1MTU1MDQyfQ.nVIwR1ybmWjwKGlBnKYYrQQD6jFswKVBuP5gM04AOgrEpj0SpNNpRXSlwLV8Sk-OyhiTRC7UMo59SJJZol0Z6JNi8Krzw5LY6jP9Ih3tziJkxm_N2Zrhy6cfF9N0d9iMfOqd8EINAa6hdBNzlbg2gpnfS3K4YwRPxgGmSqSOGQ9W15WIg8jJNZAqw0CuUnShYNjoug-jANK6jM5lDjKtdjahoo-FFugdWXcHwiDLycXr6ocG7ERGSwtPvQB5h058XlpU3CEoONq95hRSQCdc47iEheMTAvh_4RumNhzYgr5lBFC-m9dyUyiHaGLYb6C3aNb-DQdZEdZPElYdbN0YFQ	\N
cms37qbcp000004jldlm5roy0	oidc	google	100352920718100813505	\N	ya29.a0ARGnu0YMtGWrww8zyMopkaAnq-3iPaPjyxo4JQ4hJ9ASGhxHQ7ftjkafyzuCwa7EG2D3wHXpTTQJUm7yBnNe47VrDyqA0TSyPB9LR8G3zzT50D-z7kvhCvfn5XoM_cKcY3Z_4wRUOrYaSB0TqXxsKsctmZ5-9PXNDI4CCowWdudBXk49_3BBzOluObPZPhTn1MzJfzUaCgYKAfcSARcSFQHGX2Mi2TglX0TCH3tDvaymIA_K-A0206	1785159497	bearer	https://www.googleapis.com/auth/userinfo.email openid https://www.googleapis.com/auth/userinfo.profile	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDAzNTI5MjA3MTgxMDA4MTM1MDUiLCJlbWFpbCI6Im1rb3JvYm9rMDdAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJoQ3hTUUFaNzdpQXlFSGNxRHlYLWN3IiwibmFtZSI6Ik1hcmdvdCIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NKUFN6WEZjZzZoZEhxbDVHZmpWcHpvZ2JoWjdzdk5HYXBjMG56YU1pdkcwYzhpRmc9czk2LWMiLCJnaXZlbl9uYW1lIjoiTWFyZ290IiwiaWF0IjoxNzg1MTU1ODk4LCJleHAiOjE3ODUxNTk0OTh9.lW9mGIQUl2RNf8zzFJhyOKKy7HJH1sT8W3djk5-86rDrcYe_ethUKgsNZio3o53kYDyRlKJ05qNBdP-j_zoYh4MkxHpGdNiDFIwz1bKZCd-BVSsow-WtTfxpsxif35mdZvpWqwCHaUdbVJufv820VAM0UHy6goxrCFfua_KG8PjVSMn1lAmC9Gf19BfP5r00g97--978HGqZvcsZ_rboPc1BKNRIZm6UI50tLWoItouhML2zsrPA6btLNdXcfO9AINWVDP-EGocUtBKcTHi-YW340tq9dO0whkEDbsNf-7cwnHsPlIYetWU_HjtzxlyP0H4GzEjIsvnQjUqhdgKlNw	\N
cms7jjux1000004ldbqqk9i7v	oidc	google	100729604216933037533	\N	ya29.a0ARGnu0ZZMu6BB96C5s5PQ-L105Ety1VvC4bFDljMppUaYCaXCMp4bgGe7mE7ddDCYPhspp4mwgWq7qy-hBoZOTgbDlv1cnKhcdIiC6g069kcgLGzq8NZ0a5HPVCXszUecINxroLc5IEbUEuZVQ5XbvEER28q2zDCPCPPhjpEiWnYNGrYIWyz4jkXU_DJf8yCUq_cC2saCgYKAbQSARESFQHGX2MikXp4MLQmV_HWDynQoJafHQ0206	1785421215	bearer	https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email	eyJhbGciOiJSUzI1NiIsImtpZCI6ImI2ZGQ1MWU2NmQzNjAxMGJkM2JiZGZiM2M5MWExYTVmNmVjNmMxMmMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA3Mjk2MDQyMTY5MzMwMzc1MzMiLCJlbWFpbCI6ImRlbmkyMjA1ODVAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJUYWstVDNFaUVucldFd3RiXzJlb01RIiwibmFtZSI6ItCU0LXQvdC40YEg0JjQvtCz0LDQvdC-0LIiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jSkxVMzhnVGxKbGo4TmxsTXlLUmd6X0F3d0hWcTh0QmpmN3JiM2xMNUtZN2RLXzUzUnE9czk2LWMiLCJnaXZlbl9uYW1lIjoi0JTQtdC90LjRgSIsImZhbWlseV9uYW1lIjoi0JjQvtCz0LDQvdC-0LIiLCJpYXQiOjE3ODU0MTc2MTYsImV4cCI6MTc4NTQyMTIxNn0.327j34ixVUgBVFMTZaDiz9R-35lS0aGubDOXxMv7-CGMn76LF09VOPtv5zEsxkwXAIwH55rj-9a49FhY5slsYjgpBKTHXhzqO1JtXqkFnWBoWVYciFiyNxKOsuOYMYUJ1YX0LRVkLgcy-Ua8qGO_8SM4rjwPU70rZvlR_dVrRBR7PQB9j3NLfTOkoC6Jx0S1iTGclh_9JOf1JcMmZHk_g1eoK8BkQXK48ADbFeAWfK4zgkLIIq1tCu_-Wrd9lhVzRjQ7_kQRbhRcgR0guoHOuhqo_GqgBiICDcuL6-ks1UWCBIKt8x-GilYilW26fQGjH88fvsgTeU00SF73P5P1VA	\N
cmsa8ydwk000004l4hoktox9w	oidc	google	118138691973010305458	\N	ya29.a0ARGnu0aYeStxCbA0a4qdj0O0nvXMKhMqlXxmV8zW72Errdw8qgoO9TNZVRqaSZn8XI4UgXABs2bXZyzvgsk02aI5yd0UiQ0wN03vXTzYP3qUrMTJTw1bEXVs-fU8erZIjpVooGDKMWZpS1Zv5OEzWfQeNLxWR6EC1Vzg1tI3m0t0lxE4xcQe7lbrHwUwNOHpuB_Xwe4aCgYKARoSARMSFQHGX2MipMb1DFq6NboaAgZyGdGHcA0206	1785584817	bearer	https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email openid	eyJhbGciOiJSUzI1NiIsImtpZCI6ImYxMGY4NzQwNWE5NzljMWRmMzZkZjI2NjA2NzM0ZjMzY2Q4NWMyNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgxMzg2OTE5NzMwMTAzMDU0NTgiLCJlbWFpbCI6InRhcmFzLmRlbXlhbnlzaHluQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiaGRLcnZ6bENnbkFlQ2ZILUViQW9YUSIsIm5hbWUiOiJUYXJhcyBEZW15YW55c2h5biIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NKN196VjdoNkNUUFBZZ1B3RmxhUXlTdjIta0FnYVRzN0xiZm52ZVd4RjBLYXhVamc9czk2LWMiLCJnaXZlbl9uYW1lIjoiVGFyYXMiLCJmYW1pbHlfbmFtZSI6IkRlbXlhbnlzaHluIiwiaWF0IjoxNzg1NTgxMjE4LCJleHAiOjE3ODU1ODQ4MTh9.vmlA5eA8Do6QEB4PTPiV2MPslhC9sJboWPNDwQjNteVo2uAHNQ5-LRFWL4xEwuP27O3HWGsGl2wzZS0CPJaUR4mTIQDgTgkG3dg09Rznn5h462_Tac6kALWjCErCieXZBXhqSY7mbJ6rxU_Ica-D4_4HL6_Xthm61E8bvEkc4UuMAoPQavgeei62r-a3ddDmYuP1VsBLhBiPmd1hpO8l6DnHyHfAkypUeH-EqZukyLkSudxgJP0ACFs7DxfeehaS0Zly6Xc8xWsBDFIytFmi4NusRa29_AWqYuLiDq4smVWiDFuUAiFWmcDk7S-hTtEjFQZls0BNZgH30_-k6znH3A	\N
cmsaba21r000004ifvn9ov42j	oidc	google	110982986619100552254	\N	ya29.a0ARGnu0Y1zLUx3WPsjXnPtxoqL-_CKmtxENe7nFh03YSU0Q8r_Q5B55wGclV1136AZIXb3AgHbIoPh-zrjpz4qvLhJ2HBN66N8zaJe6iPz96F1_bKWTrvotRq55j3raCPS96XxqR8WB4K9H_my1cLIHEjpt5nbcXwVV9y8nCgeVZs3v10lV4gPpt7sIUDfckFYK1jtuoaCgYKAXQSARUSFQHGX2MiFidcUDCh3GrHs53slK1BLg0206	1785588720	bearer	https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid	eyJhbGciOiJSUzI1NiIsImtpZCI6ImYxMGY4NzQwNWE5NzljMWRmMzZkZjI2NjA2NzM0ZjMzY2Q4NWMyNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTA5ODI5ODY2MTkxMDA1NTIyNTQiLCJlbWFpbCI6Im5hc3RpYTI0MDEyMDAxOEBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6InlxeHc5THlYeVByemJkTzIwUnYzX1EiLCJuYW1lIjoi0JDQvdCw0YHRgtCw0YHQuNGPINCf0L7Qu9C40YnRg9C6IiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0xyaUhkN1N3ZWlQOEZUeUo0Vkh6TWt0T1VjU0VaSk9DRkh2c3F3eW56dVowUWRHZVpzPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6ItCQ0L3QsNGB0YLQsNGB0LjRjyIsImZhbWlseV9uYW1lIjoi0J_QvtC70LjRidGD0LoiLCJpYXQiOjE3ODU1ODUxMjEsImV4cCI6MTc4NTU4ODcyMX0.xNCrDG2ZxvwC8AhfJYaBrtADL9NVKGS15RfRUkacWxa2vj3Ef_wAKXq1NXEhdUeEGe5JIbi7OHX2yJ1iM0Dma-nCBSibItQYNRvW_VifAAUUv8kj4koLW18JmPIDBuP-j6LE4ykzVi-opXi0wFaLRLStZ2q8yDBpaavS1SO4p2UZNrPy5pKPur5kCSJU7Tk3Wm6Yf1Sf9KLSeCeA9ByE8dHBbCLl4eWQQcYGiYKics2BoR3ZFGwymHErHPbqjUOpG1z5vvm6v-a2PnmpGABfXdcBAmUwCJTst05y8MLO9yKf87itLx6n437MSjMrXyo6BDR7WkJtv3T9dmiVW2uphA	\N
cmsae1urh000004i9rgpt7v0s	oidc	google	116855718301740943915	\N	ya29.a0ARGnu0b81mbA4aP28beJgVjC1H1e5GpuqT2ZvFyYCRk-DZVBZAqFamvPASqvXUGE-YDOB9ktVQDFMHA6kofLw7vWT3OgcUCBWIUESePLfshYzggAX77Hw_yH2xx__FbX4sovMxpMqRjdbqmwd421L4r6v87ZZOZvit_NhUiaYjwDr8CaYLtAvvbcGUAcwaUWJqjmas8aCgYKAcASARcSFQHGX2MixNhZ6jCCiaoTyqULdW19NQ0206	1785593377	bearer	https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid	eyJhbGciOiJSUzI1NiIsImtpZCI6ImYxMGY4NzQwNWE5NzljMWRmMzZkZjI2NjA2NzM0ZjMzY2Q4NWMyNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTY4NTU3MTgzMDE3NDA5NDM5MTUiLCJlbWFpbCI6InRlcmViaXpodmljdG9yQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiemQ0V2JuNTd5eU1CT1ZjNjg4TF9LdyIsIm5hbWUiOiJURVJFTSBCRUFUUyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NJbHVWbHVtUXhoUUxoTmFRdWRncGcxWHZ1RklyREpjWldUWnpxVjljSjh6WlhwaXNtUz1zOTYtYyIsImdpdmVuX25hbWUiOiJURVJFTSIsImZhbWlseV9uYW1lIjoiQkVBVFMiLCJpYXQiOjE3ODU1ODk3NzgsImV4cCI6MTc4NTU5MzM3OH0.NKsxJO0rgAynE4UAzwXM_0WlOrPEC3FJ02sNXjHy4PuoOtiJ35FmLAiTb3QlMAVhO9n68lqdked6urPEjw4kvn69IeIy5NVZwzAHx5Fy7gctUYCTv2g1NT4xblqgt6i_XG9X6acAAFuhodlnWXOnuTN7eMTm32xYzLTjD0jtccYS0VrT2CakqtbhEJohwg70tSMMBlgoxkFoms5XENcahpVRwXHmJ6S9vGQWMmkVWeYIfnwlukaeCKYxIl_ATlc_A2aE75YIR7FlmoENeNs0VX3SC_-tu5Nm5P1EeTfzuqy8x1eQkD3W35HpfZ-r5uE5-niBnpsve4-Zd0BwHJzzyA	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "actorId", "actorLabel", action, "entityType", "entityId", summary, "createdAt") FROM stdin;
cms8y7ls70002ywtdzd0k2b0x	\N	E2E Admin	player.create	Player	cms8y7llq0001ywtdo0frl2vj	Створено гравця "Playwright Explore Player 1785502702833"	2026-07-31 12:58:26.695
cms8y7oia0004ywtdg5w55gz7	\N	E2E Admin	tournament.create	Tournament	cms8y7oed0003ywtdujoew71l	Створено турнір "Playwright Explore Cup 1785502708467"	2026-07-31 12:58:30.226
cms8y9pi00007ywtdygt4ch42	\N	E2E Admin	player.create	Player	cms8y9pex0006ywtd571lpq6w	Створено гравця "Playwright Match Flow A 1785502799406"	2026-07-31 13:00:04.824
cms8y9rcu0009ywtd7tf8fkkm	\N	E2E Admin	player.create	Player	cms8y9r990008ywtd1p2219yo	Створено гравця "Playwright Match Flow B 1785502799406"	2026-07-31 13:00:07.23
cms8y9u2s000bywtdo0xe2hik	\N	E2E Admin	tournament.create	Tournament	cms8y9ty3000aywtdv3xvju2s	Створено турнір "Playwright Match Flow Cup 1785502799406"	2026-07-31 13:00:10.756
cms8yb10o000eywtdgmhjreqo	\N	E2E Admin	player.create	Player	cms8yb0ta000dywtdw3196ij5	Створено гравця "Playwright Match Flow A 1785502862988"	2026-07-31 13:01:06.408
cms8yb2ju000gywtdhvw1l7o7	\N	E2E Admin	player.create	Player	cms8yb2g4000fywtdxb8kwl1g	Створено гравця "Playwright Match Flow B 1785502862988"	2026-07-31 13:01:08.394
cms8yb58b000iywtdjv4krtkk	\N	E2E Admin	tournament.create	Tournament	cms8yb52c000hywtd4sz49fuo	Створено турнір "Playwright Match Flow Cup 1785502862988"	2026-07-31 13:01:11.867
cms8ybnm4000lywtdys6977n2	\N	E2E Admin	player.create	Player	cms8ybng4000kywtdqqukd8um	Створено гравця "Playwright Match Flow A 1785502892024"	2026-07-31 13:01:35.693
cms8ybpr3000nywtdfo9cb3cm	\N	E2E Admin	player.create	Player	cms8ybpjt000mywtd33jtqbch	Створено гравця "Playwright Match Flow B 1785502892024"	2026-07-31 13:01:38.463
cms8ybt4n000pywtdqr9s207t	\N	E2E Admin	tournament.create	Tournament	cms8ybsxm000oywtdu13yn56r	Створено турнір "Playwright Match Flow Cup 1785502892024"	2026-07-31 13:01:42.839
cms8ydke4000sywtdq7ulr0tw	\N	E2E Admin	player.create	Player	cms8ydkak000rywtde21mofgk	Створено гравця "Playwright Match Flow A 1785502981031"	2026-07-31 13:03:04.828
cms8ydm7j000uywtdskjv0ttb	\N	E2E Admin	player.create	Player	cms8ydm35000tywtd8p9c77c4	Створено гравця "Playwright Match Flow B 1785502981031"	2026-07-31 13:03:07.183
cms8ydp2a000wywtd2zgk56qu	\N	E2E Admin	tournament.create	Tournament	cms8ydoxt000vywtdilc4mu80	Створено турнір "Playwright Match Flow Cup 1785502981031"	2026-07-31 13:03:10.883
cms8ygcog000zywtd9dcahz68	\N	E2E Admin	player.create	Player	cms8ygch0000yywtdk15r8c90	Створено гравця "Playwright Match Flow A 1785503111656"	2026-07-31 13:05:14.8
cms8ygefk0011ywtdnpxcee5q	\N	E2E Admin	player.create	Player	cms8yge8l0010ywtd7nzaxavw	Створено гравця "Playwright Match Flow B 1785503111656"	2026-07-31 13:05:17.072
cms8yggxb0013ywtdy9g1dset	\N	E2E Admin	tournament.create	Tournament	cms8yggsk0012ywtdku486elx	Створено турнір "Playwright Match Flow Cup 1785503111656"	2026-07-31 13:05:20.303
cms8yhuie0016ywtdsq0hvxcg	\N	E2E Admin	player.create	Player	cms8yhudm0015ywtduyfczjxv	Створено гравця "Playwright Match Flow A 1785503181370"	2026-07-31 13:06:24.566
cms8yhx190018ywtdbp7v325m	\N	E2E Admin	tournament.create	Tournament	cms8yhwwp0017ywtdkjwstahv	Створено турнір "Playwright Match Flow Cup 1785503181370"	2026-07-31 13:06:27.837
cms8yj00r001bywtd2tl6zia3	\N	E2E Admin	player.create	Player	cms8yizwe001aywtdn3notvu3	Створено гравця "Playwright Match Flow A 1785503235229"	2026-07-31 13:07:18.363
cms8yj2cs001dywtd9w5zvvxc	\N	E2E Admin	tournament.create	Tournament	cms8yj27f001cywtdmfq90i1c	Створено турнір "Playwright Match Flow Cup 1785503235229"	2026-07-31 13:07:21.388
cms8ym76e001gywtdcvulsxfl	\N	E2E Admin	player.create	Player	cms8ym6wd001fywtdkywgohcn	Створено гравця "Playwright Match Flow A 1785503382462"	2026-07-31 13:09:47.606
cms8ym9bo001iywtdqys9muhf	\N	E2E Admin	player.create	Player	cms8ym977001hywtd39iejpih	Створено гравця "Playwright Match Flow B 1785503382462"	2026-07-31 13:09:50.388
cms8ymceg001kywtd8r0w8ezm	\N	E2E Admin	tournament.create	Tournament	cms8ymc9x001jywtdyqxy5bn9	Створено турнір "Playwright Match Flow Cup 1785503382462"	2026-07-31 13:09:54.377
cms8yosqk001pywtdioeazz7c	\N	E2E Admin	player.create	Player	cms8yosl9001oywtdmoc1owjf	Створено гравця "Playwright Match Flow A 1785503505059"	2026-07-31 13:11:48.86
cms8youtw001rywtdvx86gzdk	\N	E2E Admin	player.create	Player	cms8youo8001qywtd27tx5745	Створено гравця "Playwright Match Flow B 1785503505059"	2026-07-31 13:11:51.572
cms8yoxq9001tywtdnzxjq4je	\N	E2E Admin	tournament.create	Tournament	cms8yoxm7001sywtdcshq8lqk	Створено турнір "Playwright Match Flow Cup 1785503505059"	2026-07-31 13:11:55.329
cms8yr4k5001xywtdpymufz86	\N	E2E Admin	player.create	Player	cms8yr4cs001wywtdr8mp6v36	Створено гравця "Playwright Match Flow A 1785503614078"	2026-07-31 13:13:37.493
cms8yr643001zywtddgv7n8ul	\N	E2E Admin	player.create	Player	cms8yr61p001yywtdqsl0j8ow	Створено гравця "Playwright Match Flow B 1785503614078"	2026-07-31 13:13:39.507
cms8yr8f70021ywtdtcgczh2h	\N	E2E Admin	tournament.create	Tournament	cms8yr8a30020ywtdhrv5jw2s	Створено турнір "Playwright Match Flow Cup 1785503614078"	2026-07-31 13:13:42.499
cms8yt8e7002jywtde3n8wy3x	\N	E2E Admin	player.create	Player	cms8yt8a0002iywtd84cu8po3	Створено гравця "Playwright Match Flow B 1785503709837"	2026-07-31 13:15:15.775
cms8yrdgr0024ywtd4ne70lyd	\N	E2E Admin	tournament.participant.add	Tournament	cms8yr8a30020ywtdhrv5jw2s	Додано 2 учасник(ів) до турніру	2026-07-31 13:13:49.035
cms8ysb750027ywtdglzd50r6	\N	E2E Admin	player.create	Player	cms8ysb1c0026ywtdcvw3874h	Створено гравця "Playwright Match Flow A 1785503669641"	2026-07-31 13:14:32.753
cms8ysdb80029ywtdll9d0ezn	\N	E2E Admin	player.create	Player	cms8ysd6q0028ywtd01pyv6ue	Створено гравця "Playwright Match Flow B 1785503669641"	2026-07-31 13:14:35.492
cms8ysg4i002bywtdr4dsfa8a	\N	E2E Admin	tournament.create	Tournament	cms8ysfz9002aywtd8spwo8p6	Створено турнір "Playwright Match Flow Cup 1785503669641"	2026-07-31 13:14:39.138
cms8yslrv002eywtdx0jhcmw7	\N	E2E Admin	tournament.participant.add	Tournament	cms8ysfz9002aywtd8spwo8p6	Додано 2 учасник(ів) до турніру	2026-07-31 13:14:46.459
cms8yt6db002hywtdnm3ipd3h	\N	E2E Admin	player.create	Player	cms8yt68i002gywtd5laor613	Створено гравця "Playwright Match Flow A 1785503709837"	2026-07-31 13:15:13.151
cms8ytba5002lywtd6d2rucqe	\N	E2E Admin	tournament.create	Tournament	cms8ytb41002kywtdaoam0yrh	Створено турнір "Playwright Match Flow Cup 1785503709837"	2026-07-31 13:15:19.517
cms8ytg9y002oywtdi724go6s	\N	E2E Admin	tournament.participant.add	Tournament	cms8ytb41002kywtdaoam0yrh	Додано 2 учасник(ів) до турніру	2026-07-31 13:15:25.99
cms8yu29c002rywtdl80cvthb	\N	E2E Admin	player.create	Player	cms8yu26b002qywtdeggwcjrv	Створено гравця "Playwright Match Flow A 1785503751276"	2026-07-31 13:15:54.48
cms8yu448002tywtdo2thix9h	\N	E2E Admin	player.create	Player	cms8yu3xf002sywtdu8di940x	Створено гравця "Playwright Match Flow B 1785503751276"	2026-07-31 13:15:56.888
cms8yu6sv002vywtdsxwzbaqx	\N	E2E Admin	tournament.create	Tournament	cms8yu6oh002uywtdggggbf6w	Створено турнір "Playwright Match Flow Cup 1785503751276"	2026-07-31 13:16:00.367
cms8yua9b002yywtdnpv7ps85	\N	E2E Admin	tournament.participant.add	Tournament	cms8yu6oh002uywtdggggbf6w	Додано 2 учасник(ів) до турніру	2026-07-31 13:16:04.847
cms8yvkw70031ywtdzjmpn4u9	\N	E2E Admin	player.create	Player	cms8yvkp80030ywtdn0skcd0k	Створено гравця "Playwright Match Flow A 1785503821639"	2026-07-31 13:17:05.287
cms8yvmz40033ywtdyob5ry0a	\N	E2E Admin	player.create	Player	cms8yvmvu0032ywtdigekqmn5	Створено гравця "Playwright Match Flow B 1785503821639"	2026-07-31 13:17:07.984
cms8yvpzu0035ywtdidvih4qx	\N	E2E Admin	tournament.create	Tournament	cms8yvpsk0034ywtd1hqb0g5p	Створено турнір "Playwright Match Flow Cup 1785503821639"	2026-07-31 13:17:11.898
cms8yvu250038ywtdx8qtcjq4	\N	E2E Admin	tournament.participant.add	Tournament	cms8yvpsk0034ywtd1hqb0g5p	Додано 2 учасник(ів) до турніру	2026-07-31 13:17:17.165
cms8yzieh0002n8td56nkeh18	\N	E2E Admin	player.create	Player	cms8yzi6w0001n8tdr322ks02	Створено гравця "Playwright Match Flow A 1785504000973"	2026-07-31 13:20:08.681
cms8yzkcy0004n8td9ke67xgx	\N	E2E Admin	player.create	Player	cms8yzk6o0003n8td8rvaj0ct	Створено гравця "Playwright Match Flow B 1785504000973"	2026-07-31 13:20:11.218
cms8yzokc0006n8td9silno1w	\N	E2E Admin	tournament.create	Tournament	cms8yzogt0005n8tdkh3d0j35	Створено турнір "Playwright Match Flow Cup 1785504000973"	2026-07-31 13:20:16.668
cms8z14kf000an8tdcm0digx2	\N	E2E Admin	player.create	Player	cms8z14eb0009n8tdk4xz79sz	Створено гравця "Playwright Match Flow A 1785504079656"	2026-07-31 13:21:24.063
cms8z17pi000cn8tdfr1d33n1	\N	E2E Admin	tournament.create	Tournament	cms8z17l7000bn8tdqtgl283v	Створено турнір "Playwright Match Flow Cup 1785504079656"	2026-07-31 13:21:28.134
cms8z1b9k000en8tda1o3qc6h	\N	E2E Admin	tournament.participant.add	Tournament	cms8z17l7000bn8tdqtgl283v	Додано 1 учасник(ів) до турніру	2026-07-31 13:21:32.744
cms8z4pcv000hn8tdehp57wgw	\N	E2E Admin	player.create	Player	cms8z4p8z000gn8tdnzvnoydy	Створено гравця "Playwright Match Flow A 1785504249280"	2026-07-31 13:24:10.975
cms8z5gc9000kn8td1wrbuw1i	\N	E2E Admin	player.create	Player	cms8z5g50000jn8tde04klv1c	Створено гравця "Playwright Match Flow A 1785504284646"	2026-07-31 13:24:45.945
cms8z6fzl000nn8tdmnj2a943	\N	E2E Admin	player.create	Player	cms8z6ftj000mn8tdtnttjo4x	Створено гравця "Playwright Match Flow A 1785504328951"	2026-07-31 13:25:32.145
cms8z6j6y000pn8tdgerjl2wa	\N	E2E Admin	tournament.create	Tournament	cms8z6j2v000on8tdrffjk6lw	Створено турнір "Playwright Match Flow Cup 1785504328951"	2026-07-31 13:25:36.298
cms8z6msw000rn8tdzisqzsg9	\N	E2E Admin	tournament.participant.add	Tournament	cms8z6j2v000on8tdrffjk6lw	Додано 1 учасник(ів) до турніру	2026-07-31 13:25:40.976
cms8z8xf6000un8tdypc3ffht	\N	E2E Admin	player.create	Player	cms8z8x8t000tn8tdnstbayez	Створено гравця "Playwright Match Flow A 1785504444617"	2026-07-31 13:27:28.05
cms8z90jc000wn8tdmadkr48z	\N	E2E Admin	player.create	Player	cms8z90c1000vn8tdoxy7hpyp	Створено гравця "Playwright Match Flow B 1785504444617"	2026-07-31 13:27:32.088
cms8z9w4i000zn8td6erjtk6o	\N	E2E Admin	player.create	Player	cms8z9vwo000yn8td2czuczbc	Створено гравця "Playwright Match Flow A 1785504489310"	2026-07-31 13:28:13.026
cms8z9y8l0011n8tdcc4a1kue	\N	E2E Admin	player.create	Player	cms8z9y2g0010n8td69viktww	Створено гравця "Playwright Match Flow B 1785504489310"	2026-07-31 13:28:15.765
cms8za1dv0013n8td5vngj7nb	\N	E2E Admin	tournament.create	Tournament	cms8za1870012n8tdfuw2dg1o	Створено турнір "Playwright Match Flow Cup 1785504489310"	2026-07-31 13:28:19.843
cms8za61b0016n8tdukn1338e	\N	E2E Admin	tournament.participant.add	Tournament	cms8za1870012n8tdfuw2dg1o	Додано 2 учасник(ів) до турніру	2026-07-31 13:28:25.871
cms8zaayw001bn8tdnd2r4zf9	\N	E2E Admin	match.create	Match	cms8zaajo0018n8td89mz3j3g	Створено матч (SINGLES) у турнірі cms8za1870012n8tdfuw2dg1o	2026-07-31 13:28:32.264
cms8zaglt001en8tdphtk37ac	\N	E2E Admin	match.score	Match	cms8zaajo0018n8td89mz3j3g	Збережено рахунок матчу	2026-07-31 13:28:39.569
cms8zalyf001in8tdz439wwm3	\N	E2E Admin	match.randomize	Tournament	cms8za1870012n8tdfuw2dg1o	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:28:46.503
cms8zb4c7001nn8td30um9awt	\N	E2E Admin	player.create	Player	cms8zb468001mn8tda4z5bpe3	Створено гравця "Playwright Player 1785504545958"	2026-07-31 13:29:10.327
cms8zbb1x001qn8tdl23excpf	\N	E2E Admin	tournament.create	Tournament	cms8zbazf001pn8tdcv0nw4sx	Створено турнір "Playwright Cup 1785504551984"	2026-07-31 13:29:19.029
cms8zbgqu001tn8tdf2acz6gl	\N	E2E Admin	player.create	Player	cms8zbgmp001sn8td1npdh49c	Створено гравця "Playwright Match Flow A 1785504562793"	2026-07-31 13:29:26.406
cms8zbinw001vn8td96hjr4c8	\N	E2E Admin	player.create	Player	cms8zbiir001un8tdsmc7jhm6	Створено гравця "Playwright Match Flow B 1785504562793"	2026-07-31 13:29:28.892
cms8zblx5001xn8tdog9yojqu	\N	E2E Admin	tournament.create	Tournament	cms8zbltl001wn8tdk1cofbfw	Створено турнір "Playwright Match Flow Cup 1785504562793"	2026-07-31 13:29:33.113
cms8zbr7h0020n8tdps36xaz2	\N	E2E Admin	tournament.participant.add	Tournament	cms8zbltl001wn8tdk1cofbfw	Додано 2 учасник(ів) до турніру	2026-07-31 13:29:39.965
cms8zbyt50025n8tdp5486nvp	\N	E2E Admin	match.create	Match	cms8zbxlw0022n8tdf2ijddg8	Створено матч (SINGLES) у турнірі cms8zbltl001wn8tdk1cofbfw	2026-07-31 13:29:49.817
cms8zc4040028n8tdkpuwwekx	\N	E2E Admin	match.score	Match	cms8zbxlw0022n8tdf2ijddg8	Збережено рахунок матчу	2026-07-31 13:29:56.548
cms8zcbq7002cn8tdfo6g95m6	\N	E2E Admin	match.randomize	Tournament	cms8zbltl001wn8tdk1cofbfw	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:30:06.559
cms8zsiqp0002ektdlxpdm99w	\N	E2E Admin	player.create	Player	cms8zshx60001ektdiwue4kjm	Створено гравця "Playwright Match Flow A 1785505355456"	2026-07-31 13:42:42.145
cms8zskjh0004ektdmz1s2r51	\N	E2E Admin	player.create	Player	cms8zsk150003ektdq9ub3uhd	Створено гравця "Playwright Match Flow B 1785505355456"	2026-07-31 13:42:44.477
cms8zspbb0006ektdahbza3gt	\N	E2E Admin	tournament.create	Tournament	cms8zsmyn0005ektdokp6r7cm	Створено турнір "Playwright Match Flow Cup 1785505355456"	2026-07-31 13:42:50.663
cms8zss8c0009ektdw17kck8i	\N	E2E Admin	tournament.participant.add	Tournament	cms8zsmyn0005ektdokp6r7cm	Додано 2 учасник(ів) до турніру	2026-07-31 13:42:54.444
cms8zszaf000eektd8tuq9ij2	\N	E2E Admin	match.create	Match	cms8zswba000bektdvuzx2x1z	Створено матч (SINGLES) у турнірі cms8zsmyn0005ektdokp6r7cm	2026-07-31 13:43:03.591
cms8zt4dh000hektdnq62egls	\N	E2E Admin	match.score	Match	cms8zswba000bektdvuzx2x1z	Збережено рахунок матчу	2026-07-31 13:43:10.181
cms8zt8ot000lektdwuq16yf9	\N	E2E Admin	match.randomize	Tournament	cms8zsmyn0005ektdokp6r7cm	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-07-31 13:43:15.774
cms8ztulr000oektduny9ixmy	\N	E2E Admin	player.create	Player	cms8ztu3s000nektdmy5nhg8x	Створено гравця "Playwright Match Flow A 1785505420734"	2026-07-31 13:43:44.175
cms8zty3n000qektdyd0yx8wm	\N	E2E Admin	tournament.create	Tournament	cms8ztwjx000pektdjcyplw0v	Створено турнір "Playwright Match Flow Cup 1785505420734"	2026-07-31 13:43:48.707
cms8zu0t2000sektdfuklljqn	\N	E2E Admin	tournament.participant.add	Tournament	cms8ztwjx000pektdjcyplw0v	Додано 1 учасник(ів) до турніру	2026-07-31 13:43:52.214
cms9bzm3q000104jlzbjwr53x	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.create	Tournament	cms9bzlta000004jljxxeodss	Створено турнір "Тест"	2026-07-31 19:24:08.486
cms9c09x4000c04l2a4xd33ts	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.add	Tournament	cms9bzlta000004jljxxeodss	Додано 12 учасник(ів) до турніру	2026-07-31 19:24:39.352
cms9c0h63000d04l2x6mcrkzl	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37in3h000004i8eoz8ipze	2026-07-31 19:24:48.747
cms9c0lku000204jljl2u96qg	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37zfzn0005hgtd7gza4cvn	2026-07-31 19:24:54.462
cms9c0n0g000004l71uv52voh	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms6henfo000004l6bztvhooq	2026-07-31 19:24:56.32
cms9c0nkj000104l7d2r9jjo6	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms66zpp4000004i916qdj51o	2026-07-31 19:24:57.043
cms9c0r5i000004kzcq51872h	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms37hxxp000004kv12xpq61b	2026-07-31 19:25:01.686
cms9c0sow000104kz5u80dhzt	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cms9bzlta000004jljxxeodss	Позначено сіяним гравця cms4if36v000004l8sq7n50wi	2026-07-31 19:25:03.68
cms9c1kuo001q04kzj8y0u1n0	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cms9bzlta000004jljxxeodss	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-07-31 19:25:40.176
cms9c2ctr000304l7zudvk8cm	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	2581d722-8cd1-42cb-bf64-538b322e70c3	Збережено рахунок матчу	2026-07-31 19:26:16.431
cms9c2tt7000504l7b39w7kkn	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	bcefca21-1aa8-4e87-9d24-08daf9f85d75	Збережено рахунок матчу	2026-07-31 19:26:38.443
cms9c32wj000604l7v0r2b2ph	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.delete	Tournament	cms9bzlta000004jljxxeodss	Видалено турнір "Тест"	2026-07-31 19:26:50.227
cms9y84ij001o04i5jvh5zadf	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cms38gx1f000004jnvhqe1ilw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-01 05:46:37.147
cms9yhg9f000004l0sr451l32	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.update	Tournament	cms38gx1f000004jnvhqe1ilw	Оновлено турнір "01.08.2026"	2026-08-01 05:53:52.275
cmsa0n3f9000104l49m8wixx3	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	51d6f2f4-0ea8-443b-9688-dc564327a866	Збережено рахунок матчу	2026-08-01 06:54:14.805
cmsa0nlcz000104jl2ikb6d3j	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	e36517b3-fbfd-4a99-8859-26024ff671b8	Збережено рахунок матчу	2026-08-01 06:54:38.051
cmsa0obaj000304jl14z1gdwk	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	a3f8eafb-84d6-425d-8d2e-a6dcaf4a1c39	Збережено рахунок матчу	2026-08-01 06:55:11.659
cmsa0rstm000504jlkzu5bye4	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	ee257a03-8b87-4d91-a61d-9df22e166002	Збережено рахунок матчу	2026-08-01 06:57:54.346
cmsa0s85f000004jxmdc53x57	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.delete	Match	a3f8eafb-84d6-425d-8d2e-a6dcaf4a1c39	Видалено матч у турнірі cms38gx1f000004jnvhqe1ilw	2026-08-01 06:58:14.211
cmsa0svlx000604jx0x2j8kkj	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.create	Match	cmsa0svho000104jxfol8sj3q	Створено матч (DOUBLES) у турнірі cms38gx1f000004jnvhqe1ilw	2026-08-01 06:58:44.613
cmsa2ams5000104jodhfity60	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	1d711576-4746-4724-a62b-d6dd93fa47d8	Збережено рахунок матчу	2026-08-01 07:40:32.597
cmsa2ov5y000104l846xgyud2	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	f344a167-4923-46f0-9ebf-c105f540d58f	Збережено рахунок матчу	2026-08-01 07:51:36.646
cmsa2w0et000304l80bej7slf	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	13701177-c88f-465e-8fdf-cc27dfa85c87	Збережено рахунок матчу	2026-08-01 07:57:10.038
cmsa4k4g5000104l0erbtkjio	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	Збережено рахунок матчу	2026-08-01 08:43:54.63
cmsa4ky5j000104jrdrjafdse	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	4434902a-b2d3-470e-ad38-739944ee506b	Збережено рахунок матчу	2026-08-01 08:44:33.127
cmsa4l6zx000304jrdspgnslu	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	Збережено рахунок матчу	2026-08-01 08:44:44.589
cmsa6zm17000104jx8k92qcct	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	3c2c1914-1e20-43f7-9270-19f21023f658	Збережено рахунок матчу	2026-08-01 09:51:56.491
cmsa8htu4000104jjyf221ixb	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	061a18d3-b68c-4607-99d4-a51049ed93f7	Збережено рахунок матчу	2026-08-01 10:34:06.028
cmsa8ixgo000304jj1rpll6ki	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	a61128b1-cac0-4f43-890c-c63194b90396	Збережено рахунок матчу	2026-08-01 10:34:57.384
cmsa8jns8000104ky7pqi6p1o	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	cmsa0svho000104jxfol8sj3q	Збережено рахунок матчу	2026-08-01 10:35:31.496
cmsa8mty4000504jjgn3yyn7t	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	18377367-84a9-4a8c-9c98-3dbfa05b4700	Збережено рахунок матчу	2026-08-01 10:37:59.452
cmsa8qm5d000704jj4rgn85bq	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	fd0d2451-feee-4657-a824-ad1e00874173	Збережено рахунок матчу	2026-08-01 10:40:55.969
cmsa8sulc000004l52nmckz4o	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.update	Tournament	cms38gx1f000004jnvhqe1ilw	Оновлено турнір "01.08.2026"	2026-08-01 10:42:40.224
cmsabac9r000004k6wupm68vh	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	player.link	Player	cms37hxxp000004kv12xpq61b	Прив'язано акаунт (taras.demyanyshyn@gmail.com) до гравця "Демʼянішин Тарас"	2026-08-01 11:52:15.519
cmsabj6x30002p8tdw305yx19	\N	E2E Admin	player.create	Player	cmsabj6ot0001p8td0k5zvspc	Створено гравця "Playwright Match Flow A 1785585545566"	2026-08-01 11:59:08.487
cmsabj7ru0004p8tdktglat26	\N	E2E Admin	player.create	Player	cmsabj7jo0003p8tdgyxeby37	Створено гравця "Playwright Match Flow B 1785585545566"	2026-08-01 11:59:09.595
cmsabjagg0006p8tdra1ynfgr	\N	E2E Admin	tournament.create	Tournament	cmsabj96n0005p8tdlgl8ggry	Створено турнір "Playwright Match Flow Cup 1785585545566"	2026-08-01 11:59:13.073
cmsabjcc30009p8td41b7h30p	\N	E2E Admin	tournament.participant.add	Tournament	cmsabj96n0005p8tdlgl8ggry	Додано 2 учасник(ів) до турніру	2026-08-01 11:59:15.507
cmsabjfk6000dp8td2c7a08fr	\N	E2E Admin	match.create	Match	cmsabjf00000ap8tdkqekybpt	Створено матч (SINGLES) у турнірі cmsabj96n0005p8tdlgl8ggry	2026-08-01 11:59:19.686
cmsabliyy000gp8tdd18iawrn	\N	E2E Admin	player.create	Player	cmsabliq3000fp8tdl6n8bz0n	Створено гравця "Playwright Match Flow A 1785585654714"	2026-08-01 12:00:57.418
cmsabljx1000ip8tdwewsox3x	\N	E2E Admin	player.create	Player	cmsabljnn000hp8tdvn69oxz1	Створено гравця "Playwright Match Flow B 1785585654714"	2026-08-01 12:00:58.645
cmsablmoj000kp8tdos68ynwf	\N	E2E Admin	tournament.create	Tournament	cmsabll5h000jp8td7qmoyd9f	Створено турнір "Playwright Match Flow Cup 1785585654714"	2026-08-01 12:01:02.227
cmsablonb000np8tdmkdp25ai	\N	E2E Admin	tournament.participant.add	Tournament	cmsabll5h000jp8td7qmoyd9f	Додано 2 учасник(ів) до турніру	2026-08-01 12:01:04.775
cmsabls3l000rp8tdjqzxvmu4	\N	E2E Admin	match.create	Match	cmsablr0j000op8tdomzk80hl	Створено матч (SINGLES) у турнірі cmsabll5h000jp8td7qmoyd9f	2026-08-01 12:01:09.249
cmsabmv4p000up8td9s3i6dzh	\N	E2E Admin	player.create	Player	cmsabmuuu000tp8tdy6od2o1w	Створено гравця "Playwright Match Flow A 1785585717608"	2026-08-01 12:01:59.833
cmsabmwei000wp8tdq92e3ji8	\N	E2E Admin	player.create	Player	cmsabmw47000vp8tdd1d4ff37	Створено гравця "Playwright Match Flow B 1785585717608"	2026-08-01 12:02:01.482
cmsabmzaz000yp8tdp86pij5e	\N	E2E Admin	tournament.create	Tournament	cmsabmxwg000xp8td1k4grgp2	Створено турнір "Playwright Match Flow Cup 1785585717608"	2026-08-01 12:02:05.243
cmsabn10s0011p8tdnoz2ruzp	\N	E2E Admin	tournament.participant.add	Tournament	cmsabmxwg000xp8td1k4grgp2	Додано 2 учасник(ів) до турніру	2026-08-01 12:02:07.468
cmsabn48h0015p8tdy8sczs8q	\N	E2E Admin	match.create	Match	cmsabn3nl0012p8tdzm08dr92	Створено матч (SINGLES) у турнірі cmsabmxwg000xp8td1k4grgp2	2026-08-01 12:02:11.633
cmsabqfm40018p8tdtcli3x0l	\N	E2E Admin	player.create	Player	cmsabqfdl0017p8tdkjb8t3bj	Створено гравця "Playwright Match Flow A 1785585883939"	2026-08-01 12:04:46.348
cmsabqghj001ap8tda2udzxuw	\N	E2E Admin	player.create	Player	cmsabqg940019p8td6snx95b6	Створено гравця "Playwright Match Flow B 1785585883939"	2026-08-01 12:04:47.479
cmsabqifv001cp8td13ml7dfe	\N	E2E Admin	tournament.create	Tournament	cmsabqhng001bp8tdgba0fymw	Створено турнір "Playwright Match Flow Cup 1785585883939"	2026-08-01 12:04:50.011
cmsabqjte001fp8tdoozxtpew	\N	E2E Admin	tournament.participant.add	Tournament	cmsabqhng001bp8tdgba0fymw	Додано 2 учасник(ів) до турніру	2026-08-01 12:04:51.794
cmsabqmww001jp8tdixy42cyr	\N	E2E Admin	match.create	Match	cmsabqmag001gp8tdvxri17nn	Створено матч (SINGLES) у турнірі cmsabqhng001bp8tdgba0fymw	2026-08-01 12:04:55.809
cmsabr2iq001mp8tdmwbp4vjn	\N	E2E Admin	player.create	Player	cmsabr268001lp8tdl6hhiue0	Створено гравця "Playwright Match Flow A 1785585913904"	2026-08-01 12:05:16.034
cmsabr3mx001op8td81mylcn2	\N	E2E Admin	player.create	Player	cmsabr3e3001np8tdhjz9i7tw	Створено гравця "Playwright Match Flow B 1785585913904"	2026-08-01 12:05:17.481
cmsabr55y001qp8tdr72vcxah	\N	E2E Admin	tournament.create	Tournament	cmsabr4if001pp8td05ob1sx4	Створено турнір "Playwright Match Flow Cup 1785585913904"	2026-08-01 12:05:19.462
cmsabr75f001tp8tdcpcxzq66	\N	E2E Admin	tournament.participant.add	Tournament	cmsabr4if001pp8td05ob1sx4	Додано 2 учасник(ів) до турніру	2026-08-01 12:05:22.035
cmsabr9vs001xp8tdfp5q9axj	\N	E2E Admin	match.create	Match	cmsabr97o001up8tdeyk2wo3k	Створено матч (SINGLES) у турнірі cmsabr4if001pp8td05ob1sx4	2026-08-01 12:05:25.576
cmsabrxrg0020p8td7lvgo7gx	\N	E2E Admin	player.create	Player	cmsabrxj7001zp8tdmz5n0w6c	Створено гравця "Playwright Match Flow A 1785585954266"	2026-08-01 12:05:56.524
cmsabryxa0022p8tdn5etdrdf	\N	E2E Admin	player.create	Player	cmsabryod0021p8tdfvzh0d31	Створено гравця "Playwright Match Flow B 1785585954266"	2026-08-01 12:05:58.03
cmsabs0zs0024p8tdpqtqvafs	\N	E2E Admin	tournament.create	Tournament	cmsabs04i0023p8td6ry1nsml	Створено турнір "Playwright Match Flow Cup 1785585954266"	2026-08-01 12:06:00.712
cmsabs2c90027p8td5kd4xs3s	\N	E2E Admin	tournament.participant.add	Tournament	cmsabs04i0023p8td6ry1nsml	Додано 2 учасник(ів) до турніру	2026-08-01 12:06:02.457
cmsabs5e7002bp8tdx0gyvcjt	\N	E2E Admin	match.create	Match	cmsabs4ss0028p8tdbd9j7dbo	Створено матч (SINGLES) у турнірі cmsabs04i0023p8td6ry1nsml	2026-08-01 12:06:06.415
cmsabtec5002ep8tdkm6cqsbg	\N	E2E Admin	player.create	Player	cmsabtdzo002dp8tdneypz7lu	Створено гравця "Playwright Match Flow A 1785586022239"	2026-08-01 12:07:04.661
cmsabtfej002gp8tdacmgtndh	\N	E2E Admin	player.create	Player	cmsabtf6o002fp8tdc30iznmh	Створено гравця "Playwright Match Flow B 1785586022239"	2026-08-01 12:07:06.043
cmsabth7l002ip8tdvuhe0dzq	\N	E2E Admin	tournament.create	Tournament	cmsabtgeq002hp8tdtt14t824	Створено турнір "Playwright Match Flow Cup 1785586022239"	2026-08-01 12:07:08.385
cmsabtjis002lp8tdyb72s147	\N	E2E Admin	tournament.participant.add	Tournament	cmsabtgeq002hp8tdtt14t824	Додано 2 учасник(ів) до турніру	2026-08-01 12:07:11.38
cmsabtlr7002pp8tdvxtsgd43	\N	E2E Admin	match.create	Match	cmsabtl5p002mp8tdgb5vn34h	Створено матч (SINGLES) у турнірі cmsabtgeq002hp8tdtt14t824	2026-08-01 12:07:14.275
cmsabw9vs002sp8tdse14lwjd	\N	E2E Admin	player.create	Player	cmsabw9lw002rp8tdrd30gu89	Створено гравця "Playwright Match Flow A 1785586154679"	2026-08-01 12:09:18.856
cmsabwb1u002up8td7aevn0uw	\N	E2E Admin	player.create	Player	cmsabwat3002tp8tdd6xtfgci	Створено гравця "Playwright Match Flow B 1785586154679"	2026-08-01 12:09:20.37
cmsabwde2002wp8tdk2tol3nn	\N	E2E Admin	tournament.create	Tournament	cmsabwby4002vp8tdndmgjba2	Створено турнір "Playwright Match Flow Cup 1785586154679"	2026-08-01 12:09:23.402
cmsabwf2v002zp8tdnhskgk7r	\N	E2E Admin	tournament.participant.add	Tournament	cmsabwby4002vp8tdndmgjba2	Додано 2 учасник(ів) до турніру	2026-08-01 12:09:25.591
cmsabwied0033p8td87gwwh1p	\N	E2E Admin	match.create	Match	cmsabwhv20030p8td9xup8k5o	Створено матч (SINGLES) у турнірі cmsabwby4002vp8tdndmgjba2	2026-08-01 12:09:29.893
cmsabwuoe0036p8tdb96v4cps	\N	E2E Admin	player.create	Player	cmsabwucz0035p8tdrjx5qro6	Створено гравця "Playwright Match Flow A 1785586183038"	2026-08-01 12:09:45.806
cmsabwvsv0038p8tdub1utgzz	\N	E2E Admin	player.create	Player	cmsabwvjr0037p8td0dhijx1a	Створено гравця "Playwright Match Flow B 1785586183038"	2026-08-01 12:09:47.263
cmsabwxsy003ap8td0d2mcrc9	\N	E2E Admin	tournament.create	Tournament	cmsabwwt80039p8tdmxr035f8	Створено турнір "Playwright Match Flow Cup 1785586183038"	2026-08-01 12:09:49.858
cmsabwz70003dp8td8gdcnmxa	\N	E2E Admin	tournament.participant.add	Tournament	cmsabwwt80039p8tdmxr035f8	Додано 2 учасник(ів) до турніру	2026-08-01 12:09:51.66
cmsabx266003hp8tdmagrm6bt	\N	E2E Admin	match.create	Match	cmsabx1nl003ep8td2jq474bi	Створено матч (SINGLES) у турнірі cmsabwwt80039p8tdmxr035f8	2026-08-01 12:09:55.518
cmsabxjbv003mp8td0ojh705a	\N	E2E Admin	player.create	Player	cmsabxiw0003lp8td584zz6yb	Створено гравця "Playwright Player 1785586214997"	2026-08-01 12:10:17.755
cmsabxlyz003pp8td6i5ts3lb	\N	E2E Admin	tournament.create	Tournament	cmsabxktx003op8td10vtbn88	Створено турнір "Playwright Cup 1785586218494"	2026-08-01 12:10:21.179
cmsabxo0u003sp8td1u0qo6j5	\N	E2E Admin	player.create	Player	cmsabxnsc003rp8tdnggvbe89	Створено гравця "Playwright Match Flow A 1785586221592"	2026-08-01 12:10:23.838
cmsabxpdy003up8td1k2fzfs6	\N	E2E Admin	player.create	Player	cmsabxp6f003tp8tds6f0xn0w	Створено гравця "Playwright Match Flow B 1785586221592"	2026-08-01 12:10:25.606
cmsabxr2h003wp8td57husmw2	\N	E2E Admin	tournament.create	Tournament	cmsabxqjr003vp8tdqemuo82e	Створено турнір "Playwright Match Flow Cup 1785586221592"	2026-08-01 12:10:27.785
cmsabz6jn0040p8td6dc3r0k1	\N	E2E Admin	player.create	Player	cmsabz6bf003zp8td69tc1n5i	Створено гравця "Playwright Match Flow A 1785586291606"	2026-08-01 12:11:34.499
cmsabz7f00042p8tdsl46i05m	\N	E2E Admin	player.create	Player	cmsabz75a0041p8tdrdq04f1x	Створено гравця "Playwright Match Flow B 1785586291606"	2026-08-01 12:11:35.628
cmsabz9m60044p8tdpqwkkru8	\N	E2E Admin	tournament.create	Tournament	cmsabz8yf0043p8td6cztsgi3	Створено турнір "Playwright Match Flow Cup 1785586291606"	2026-08-01 12:11:38.478
cmsac0f8h0048p8td43ozr4dg	\N	E2E Admin	player.create	Player	cmsac0etj0047p8td0abtg1s8	Створено гравця "Playwright Match Flow A 1785586350324"	2026-08-01 12:12:32.417
cmsac0gap004ap8tdxpz0i2bj	\N	E2E Admin	player.create	Player	cmsac0g2s0049p8tddvhq8xtf	Створено гравця "Playwright Match Flow B 1785586350324"	2026-08-01 12:12:33.793
cmsac0hrd004cp8td85yeqzcr	\N	E2E Admin	tournament.create	Tournament	cmsac0h3e004bp8tdlaosae6l	Створено турнір "Playwright Match Flow Cup 1785586350324"	2026-08-01 12:12:35.689
cmsac2dib00026ctdm41njuz4	\N	E2E Admin	player.create	Player	cmsac2dad00016ctd1g4xvgdb	Створено гравця "Playwright Match Flow A 1785586439424"	2026-08-01 12:14:03.491
cmsac2eb400046ctdhuzfc2cq	\N	E2E Admin	player.create	Player	cmsac2e3l00036ctdwy16yb1j	Створено гравця "Playwright Match Flow B 1785586439424"	2026-08-01 12:14:04.528
cmsac2ict00066ctdoe6w1a53	\N	E2E Admin	tournament.create	Tournament	cmsac2g1d00056ctdo1zyvjx4	Створено турнір "Playwright Match Flow Cup 1785586439424"	2026-08-01 12:14:09.773
cmsac437j000a6ctdr2nepwy5	\N	E2E Admin	player.create	Player	cmsac42ze00096ctdfl7wlq51	Створено гравця "Playwright Match Flow A 1785586521520"	2026-08-01 12:15:23.455
cmsac459m000c6ctd4hrw47qt	\N	E2E Admin	tournament.create	Tournament	cmsac44k0000b6ctdujqnbeem	Створено турнір "Playwright Match Flow Cup 1785586521520"	2026-08-01 12:15:26.122
cmsac46dk000e6ctdq1v37v69	\N	E2E Admin	tournament.participant.add	Tournament	cmsac44k0000b6ctdujqnbeem	Додано 1 учасник(ів) до турніру	2026-08-01 12:15:27.56
cmsac6c68000h6ctdr29d1xpc	\N	E2E Admin	player.create	Player	cmsac6bxi000g6ctduzn4x8cw	Створено гравця "Playwright Match Flow A 1785586626084"	2026-08-01 12:17:08.384
cmsac6dqc000j6ctdq1mbu1ce	\N	E2E Admin	player.create	Player	cmsac6dhx000i6ctdnsjj77cw	Створено гравця "Playwright Match Flow B 1785586626084"	2026-08-01 12:17:10.404
cmsac6g6a000l6ctd047gblyi	\N	E2E Admin	tournament.create	Tournament	cmsac6er6000k6ctd0vj1qh70	Створено турнір "Playwright Match Flow Cup 1785586626084"	2026-08-01 12:17:13.57
cmsac8otl000p6ctdak2nnjg0	\N	E2E Admin	player.create	Player	cmsac8olh000o6ctdda0wk209	Створено гравця "Playwright Match Flow A 1785586735619"	2026-08-01 12:18:58.089
cmsac8pnq000r6ctd8faew9yp	\N	E2E Admin	player.create	Player	cmsac8pfu000q6ctdtg51acu9	Створено гравця "Playwright Match Flow B 1785586735619"	2026-08-01 12:18:59.174
cmsac8rwr000t6ctd103o3t97	\N	E2E Admin	tournament.create	Tournament	cmsac8qqp000s6ctdvnv66kkh	Створено турнір "Playwright Match Flow Cup 1785586735619"	2026-08-01 12:19:02.091
cmsac8t6p000w6ctdf2cvhlni	\N	E2E Admin	tournament.participant.add	Tournament	cmsac8qqp000s6ctdvnv66kkh	Додано 2 учасник(ів) до турніру	2026-08-01 12:19:03.745
cmsacb50p000z6ctdg1xk2ddz	\N	E2E Admin	player.create	Player	cmsacb4mq000y6ctd9v1i98hm	Створено гравця "Playwright Match Flow A 1785586849993"	2026-08-01 12:20:52.393
cmsacb64b00116ctdtx6307ck	\N	E2E Admin	player.create	Player	cmsacb5vh00106ctdcdcmeds3	Створено гравця "Playwright Match Flow B 1785586849993"	2026-08-01 12:20:53.819
cmsacb7os00136ctdimimiz1d	\N	E2E Admin	tournament.create	Tournament	cmsacb70r00126ctd2h8v0shp	Створено турнір "Playwright Match Flow Cup 1785586849993"	2026-08-01 12:20:55.852
cmsacb95j00166ctdbjbt9mfk	\N	E2E Admin	tournament.participant.add	Tournament	cmsacb70r00126ctd2h8v0shp	Додано 2 учасник(ів) до турніру	2026-08-01 12:20:57.751
cmsacbb50001b6ctdvgbpx9ma	\N	E2E Admin	match.create	Match	cmsacbavl00186ctdy7foq8zy	Створено матч (SINGLES) у турнірі cmsacb70r00126ctd2h8v0shp	2026-08-01 12:21:00.324
cmsacbddw001e6ctdiuntxq2g	\N	E2E Admin	match.score	Match	cmsacbavl00186ctdy7foq8zy	Збережено рахунок матчу	2026-08-01 12:21:03.236
cmsacbfv7001i6ctd53tx2g42	\N	E2E Admin	match.randomize	Tournament	cmsacb70r00126ctd2h8v0shp	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-08-01 12:21:06.451
cmsacbt7v001n6ctdky5cmdby	\N	E2E Admin	player.create	Player	cmsacbszq001m6ctdu4glsup5	Створено гравця "Playwright Player 1785586879886"	2026-08-01 12:21:23.755
cmsacc6bt00286ctdbdtgho3p	\N	E2E Admin	match.score	Match	cmsacc3z200226ctdyhlx3dh6	Збережено рахунок матчу	2026-08-01 12:21:40.745
cmsacbvjp001q6ctd1k2vj291	\N	E2E Admin	tournament.create	Tournament	cmsacbus9001p6ctdbasxg6lg	Створено турнір "Playwright Cup 1785586884226"	2026-08-01 12:21:26.773
cmsacbxwi001t6ctdlm7f6t4w	\N	E2E Admin	player.create	Player	cmsacbx2o001s6ctdy7bi9gvs	Створено гравця "Playwright Match Flow A 1785586887186"	2026-08-01 12:21:29.826
cmsacbyvr001v6ctdqf1y1fr6	\N	E2E Admin	player.create	Player	cmsacbynn001u6ctdzq3a63sb	Створено гравця "Playwright Match Flow B 1785586887186"	2026-08-01 12:21:31.095
cmsacc11g001x6ctdac7jrhjl	\N	E2E Admin	tournament.create	Tournament	cmsacbzwl001w6ctdijt59p4h	Створено турнір "Playwright Match Flow Cup 1785586887186"	2026-08-01 12:21:33.892
cmsacc22r00206ctd8nnvp24b	\N	E2E Admin	tournament.participant.add	Tournament	cmsacbzwl001w6ctdijt59p4h	Додано 2 учасник(ів) до турніру	2026-08-01 12:21:35.235
cmsacc47600256ctdi4v44sjy	\N	E2E Admin	match.create	Match	cmsacc3z200226ctdyhlx3dh6	Створено матч (SINGLES) у турнірі cmsacbzwl001w6ctdijt59p4h	2026-08-01 12:21:37.986
cmsacc8rl002c6ctdtdm7pyrg	\N	E2E Admin	match.randomize	Tournament	cmsacbzwl001w6ctdijt59p4h	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-08-01 12:21:43.905
cmsad7qw600045gtdq3kojhso	\N	E2E Admin	player.create	Player	cmsad7qo200035gtddny8vtr8	Створено гравця "Playwright Player 1785588371035"	2026-08-01 12:46:13.734
cmsad7ugj00075gtd90whgik9	\N	E2E Admin	tournament.create	Tournament	cmsad7sj900065gtdax4s2y7o	Створено турнір "Playwright Cup 1785588374263"	2026-08-01 12:46:18.355
cmsad7wk0000a5gtdq2hj05b7	\N	E2E Admin	player.create	Player	cmsad7wc500095gtdxfx45bpr	Створено гравця "Playwright Match Flow A 1785588378868"	2026-08-01 12:46:21.072
cmsad7xch000c5gtdyas91l0c	\N	E2E Admin	player.create	Player	cmsad7x4h000b5gtdi4wqhdyl	Створено гравця "Playwright Match Flow B 1785588378868"	2026-08-01 12:46:22.097
cmsad7yif000e5gtdczbtkb6r	\N	E2E Admin	tournament.create	Tournament	cmsad7y4q000d5gtdvde5oip5	Створено турнір "Playwright Match Flow Cup 1785588378868"	2026-08-01 12:46:23.607
cmsad8033000h5gtd609rpjod	\N	E2E Admin	tournament.participant.add	Tournament	cmsad7y4q000d5gtdvde5oip5	Додано 2 учасник(ів) до турніру	2026-08-01 12:46:25.647
cmsad820y000m5gtd763nz0sy	\N	E2E Admin	match.create	Match	cmsad81sk000j5gtdxm0klr5o	Створено матч (SINGLES) у турнірі cmsad7y4q000d5gtdvde5oip5	2026-08-01 12:46:28.162
cmsad8478000p5gtd4vevh1dg	\N	E2E Admin	match.score	Match	cmsad81sk000j5gtdxm0klr5o	Збережено рахунок матчу	2026-08-01 12:46:30.98
cmsad86uk000t5gtdx80ivycb	\N	E2E Admin	match.randomize	Tournament	cmsad7y4q000d5gtdvde5oip5	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-08-01 12:46:34.412
cmsadl8zs000104l2k1s35z8k	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	news.create	NewsPost	cmsadl8wd000004l2ab79bc4a	Створено новину "Підсумки парного турніру 2×2 🎾"	2026-08-01 12:56:43.72
cmsae70xj00024ktdcczt0hwe	\N	E2E Admin	player.create	Player	cmsae70pp00014ktddte9xhi3	Створено гравця "Playwright Match Flow A 1785590015761"	2026-08-01 13:13:39.703
cmsae71zp00044ktdd2s4wivl	\N	E2E Admin	player.create	Player	cmsae71m200034ktdi6223krz	Створено гравця "Playwright Match Flow B 1785590015761"	2026-08-01 13:13:41.077
cmsae75pr00064ktdzxy6ppdw	\N	E2E Admin	tournament.create	Tournament	cmsae735l00054ktdwhzuzqji	Створено турнір "Playwright Match Flow Cup 1785590015761"	2026-08-01 13:13:45.903
cmsae76ro00094ktd8h1w8qvn	\N	E2E Admin	tournament.participant.add	Tournament	cmsae735l00054ktdwhzuzqji	Додано 2 учасник(ів) до турніру	2026-08-01 13:13:47.268
cmsae78wd000e4ktdk53olz95	\N	E2E Admin	match.create	Match	cmsae78j0000b4ktdxerzzh2u	Створено матч (SINGLES) у турнірі cmsae735l00054ktdwhzuzqji	2026-08-01 13:13:50.029
cmsae7bm8000h4ktdgaatuk6r	\N	E2E Admin	match.score	Match	cmsae78j0000b4ktdxerzzh2u	Збережено рахунок матчу	2026-08-01 13:13:53.552
cmsae7dk5000l4ktd4fataebc	\N	E2E Admin	match.randomize	Tournament	cmsae735l00054ktdwhzuzqji	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-08-01 13:13:56.069
cmsae8bg5000104k52698oyz2	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.create	Tournament	cmsae8b5s000004k50eef4x04	Створено турнір "Тест"	2026-08-01 13:14:39.989
cmsae8onw000804ktsrem1c6e	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.add	Tournament	cmsae8b5s000004k50eef4x04	Додано 8 учасник(ів) до турніру	2026-08-01 13:14:57.116
cmsaecbe5000004jocw8bgmtx	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Позначено сіяним гравця cms36j9tj000050tdrji7jgzy	2026-08-01 13:17:46.541
cmsaecgt7000004l31s0kjpl6	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Знято позначку сіяного гравця cms36j9tj000050tdrji7jgzy	2026-08-01 13:17:53.563
cmsaecjgg000104jo8927khcp	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Позначено сіяним гравця cms378xqi0001hgtdr6l6sxef	2026-08-01 13:17:56.992
cmsaecjoh000204joaoaags1b	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Позначено сіяним гравця cms37hxxp000004kv12xpq61b	2026-08-01 13:17:57.281
cmsaecjzu000104l3gp0j852i	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Позначено сіяним гравця cms37zyg50007hgtdu0buusvi	2026-08-01 13:17:57.69
cmsaeckss000004lb5bmxl9tu	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsae8b5s000004k50eef4x04	Позначено сіяним гравця cms36j9tj000050tdrji7jgzy	2026-08-01 13:17:58.732
cmsaed1st000o04jxxc55d4a1	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsae8b5s000004k50eef4x04	Рандомайзер (парний): згенеровано 6 матч(ів)	2026-08-01 13:18:20.765
cmsaed7ww000204lbsu0mfr2u	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	0ba7e540-434c-464c-ae24-5de1dc13bd64	Збережено рахунок матчу	2026-08-01 13:18:28.688
cmsaedqjp000q04jxt4jglgj5	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	4cedb2b6-2cda-4049-a338-067267d3dec3	Збережено рахунок матчу	2026-08-01 13:18:52.838
cmsaee8he000s04jxomdr2i9g	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	fed38cea-90c9-45f3-b039-0490ea8ca45f	Збережено рахунок матчу	2026-08-01 13:19:16.082
cmsaegta3000304lbvwujvtmm	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.score	Match	0ba7e540-434c-464c-ae24-5de1dc13bd64	Збережено рахунок матчу	2026-08-01 13:21:16.347
cmsaeha4j000404lbjbrcddz5	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.delete	Tournament	cmsae8b5s000004k50eef4x04	Видалено турнір "Тест"	2026-08-01 13:21:38.179
cmsaen369000504lbiwimn7pl	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	player.link	Player	cms4if36v000004l8sq7n50wi	Прив'язано акаунт (terebizhvictor@gmail.com) до гравця "Теребіж Віктор"	2026-08-01 13:26:09.105
cmsaermjw0002cktdk4en9nnf	\N	E2E Admin	player.create	Player	cmsaerm5n0001cktddzczl7uy	Створено гравця "Playwright Match Flow A 1785590977156"	2026-08-01 13:29:40.844
cmsaerna20004cktdbqrt0ab3	\N	E2E Admin	player.create	Player	cmsaern2f0003cktd1jqatd68	Створено гравця "Playwright Match Flow B 1785590977156"	2026-08-01 13:29:41.786
cmsaerqh70006cktdu3naaccq	\N	E2E Admin	tournament.create	Tournament	cmsaeroql0005cktd78a9ty65	Створено турнір "Playwright Match Flow Cup 1785590977156"	2026-08-01 13:29:45.931
cmsaerrcf0009cktd1nl0zpa3	\N	E2E Admin	tournament.participant.add	Tournament	cmsaeroql0005cktd78a9ty65	Додано 2 учасник(ів) до турніру	2026-08-01 13:29:47.055
cmsaertjf000ecktdcl6pur5m	\N	E2E Admin	match.create	Match	cmsaert9l000bcktd5luyyazw	Створено матч (SINGLES) у турнірі cmsaeroql0005cktd78a9ty65	2026-08-01 13:29:49.899
cmsaerv7q000hcktdp4iu2z3e	\N	E2E Admin	match.score	Match	cmsaert9l000bcktd5luyyazw	Збережено рахунок матчу	2026-08-01 13:29:52.07
cmsaerxgs000lcktd7k3zg9u1	\N	E2E Admin	match.randomize	Tournament	cmsaeroql0005cktd78a9ty65	Рандомайзер (одиночний, ALL): згенеровано 1 матч(ів)	2026-08-01 13:29:54.988
cmsbl7wqj000104lfna5rphrm	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.create	Tournament	cmsbl7vxt000004lfjh02ncaw	Створено турнір "Тест"	2026-08-02 09:18:04.411
cmsbl87jd000c04jp0gq6yrz7	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.add	Tournament	cmsbl7vxt000004lfjh02ncaw	Додано 12 учасник(ів) до турніру	2026-08-02 09:18:18.409
cmsbl8blp000004jinbrbrmir	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms37in3h000004i8eoz8ipze	2026-08-02 09:18:23.677
cmsbl8btq000104ji5g7x98q3	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Знято позначку сіяного гравця cms37in3h000004i8eoz8ipze	2026-08-02 09:18:23.966
cmsbl8bya000204jie2s50w0t	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms4ihelf000104jmwd1jh41x	2026-08-02 09:18:24.131
cmsbl8c3l000304jiffgekn1a	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms3808b20008hgtdaxtqowy3	2026-08-02 09:18:24.321
cmsbl8cfc000404jizp57bxdt	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms37in3h000004i8eoz8ipze	2026-08-02 09:18:24.744
cmsbl8cyn000d04jp9u0p2h55	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms36j9tj000050tdrji7jgzy	2026-08-02 09:18:25.439
cmsbl8dgq000204lf0717cyot	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms37zyg50007hgtdu0buusvi	2026-08-02 09:18:26.09
cmsbl8dsb000e04jpo4fyxw22	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.participant.seed	Tournament	cmsbl7vxt000004lfjh02ncaw	Позначено сіяним гравця cms37hxxp000004kv12xpq61b	2026-08-02 09:18:26.507
cmsbl8zpy002304jp50vpo0fp	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 09:18:54.934
cmsbl9l5y001t04jiok7exrkk	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 09:19:22.726
cmsbla58t003i04jiyuui90sq	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 09:19:48.749
cmsbltc0q001o04jxcmuzxvi7	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 09:34:43.994
cmsbojlkp001o04jr94ys03fr	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 10:51:08.665
cmsbokkyv003d04jrjk3ntho2	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	match.randomize	Tournament	cmsbl7vxt000004lfjh02ncaw	Рандомайзер (парний): згенеровано 15 матч(ів)	2026-08-02 10:51:54.535
cmsbold4k000004ljcn7ndmdk	cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	tournament.delete	Tournament	cmsbl7vxt000004lfjh02ncaw	Видалено турнір "Тест"	2026-08-02 10:52:31.028
\.


--
-- Data for Name: match_players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_players (id, "matchId", side, "playerId") FROM stdin;
cms9y84bb000004i58j6f5ahn	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	A	cms37in3h000004i8eoz8ipze
cms9y84bb000104i5scwk7q0o	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	A	cms36j9tj000050tdrji7jgzy
cms9y84bb000204i5h7mg37kt	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	B	cms37zfzn0005hgtd7gza4cvn
cms9y84bb000304i57iakmy5r	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	B	cms37zki10006hgtd5877avlo
cms9y84bb000404i5nkfb980e	1d711576-4746-4724-a62b-d6dd93fa47d8	A	cms37in3h000004i8eoz8ipze
cms9y84bb000504i5eafshjbn	1d711576-4746-4724-a62b-d6dd93fa47d8	A	cms36j9tj000050tdrji7jgzy
cms9y84bb000604i5kstu8o63	1d711576-4746-4724-a62b-d6dd93fa47d8	B	cms6henfo000004l6bztvhooq
cms9y84bb000704i56i8nl66z	1d711576-4746-4724-a62b-d6dd93fa47d8	B	cms6hfgdv000004icc7dad5ve
cms9y84bb000804i5aa1axiru	51d6f2f4-0ea8-443b-9688-dc564327a866	A	cms37in3h000004i8eoz8ipze
cms9y84bb000904i5vq33rutf	51d6f2f4-0ea8-443b-9688-dc564327a866	A	cms36j9tj000050tdrji7jgzy
cms9y84bs000a04i5o1kxfq0u	51d6f2f4-0ea8-443b-9688-dc564327a866	B	cms4if36v000004l8sq7n50wi
cms9y84bs000b04i57omrn8m9	51d6f2f4-0ea8-443b-9688-dc564327a866	B	cms3808b20008hgtdaxtqowy3
cms9y84bs000c04i5s8up2znk	061a18d3-b68c-4607-99d4-a51049ed93f7	A	cms37in3h000004i8eoz8ipze
cms9y84bs000d04i5wdhfhnd2	061a18d3-b68c-4607-99d4-a51049ed93f7	A	cms36j9tj000050tdrji7jgzy
cms9y84bs000e04i547sjj618	061a18d3-b68c-4607-99d4-a51049ed93f7	B	cms37hxxp000004kv12xpq61b
cms9y84bs000f04i51ipij0e1	061a18d3-b68c-4607-99d4-a51049ed93f7	B	cms4ifgek000004jm2hynvj8w
cms4j0mqu000104l4tomun2h5	cms4j0mo8000004l41m4cut27	A	cms37in3h000004i8eoz8ipze
cms4j0mqu000204l46n4dtppe	cms4j0mo8000004l41m4cut27	A	cms36j9tj000050tdrji7jgzy
cms4j0mqu000304l4aler6ppy	cms4j0mo8000004l41m4cut27	B	cms4if36v000004l8sq7n50wi
cms4j0mqu000404l4bhuw32x8	cms4j0mo8000004l41m4cut27	B	cms3808b20008hgtdaxtqowy3
cms4j4hu5000104jsaf7ftv32	cms4j4hrd000004jsmbpa99ge	A	cms37zyg50007hgtdu0buusvi
cms4j4hu5000204jszn7c08r7	cms4j4hrd000004jsmbpa99ge	A	cms37zki10006hgtd5877avlo
cms4j4hu5000304js9k8cl1wm	cms4j4hrd000004jsmbpa99ge	B	cms4ihelf000104jmwd1jh41x
cms4j4hu5000404jsjmxxxjb6	cms4j4hrd000004jsmbpa99ge	B	cms37zfzn0005hgtd7gza4cvn
cms4jbto6000104jimvd0kc87	cms4jbtlk000004ji4rrklq3q	A	cms36j9tj000050tdrji7jgzy
cms4jbto6000204jiwtfmkuf0	cms4jbtlk000004ji4rrklq3q	A	cms37in3h000004i8eoz8ipze
cms4jbto6000304ji9odsshif	cms4jbtlk000004ji4rrklq3q	B	cms37hxxp000004kv12xpq61b
cms4jbto6000404jix81i7vz9	cms4jbtlk000004ji4rrklq3q	B	cms4ifgek000004jm2hynvj8w
cms4jesm0000604jiqhqm6j0u	cms4jesjc000504jiywmobz2c	A	cms37hxxp000004kv12xpq61b
cms4jesm0000704jihc8rdeph	cms4jesjc000504jiywmobz2c	A	cms4ifgek000004jm2hynvj8w
cms4jesm0000804ji2zk40n7t	cms4jesjc000504jiywmobz2c	B	cms4if36v000004l8sq7n50wi
cms4jesm0000904jiv39prcgw	cms4jesjc000504jiywmobz2c	B	cms3808b20008hgtdaxtqowy3
cms4jhyo8000304laqyrz3uw2	cms4jhylk000204lajbn2pnu9	A	cms37zki10006hgtd5877avlo
cms4jhyo8000404la7jv89vso	cms4jhylk000204lajbn2pnu9	A	cms37zyg50007hgtdu0buusvi
cms4jhyo8000504la2irgn5bd	cms4jhylk000204lajbn2pnu9	B	cms36j9tj000050tdrji7jgzy
cms4jhyo8000604laobwdjqq9	cms4jhylk000204lajbn2pnu9	B	cms37in3h000004i8eoz8ipze
cms4k0osn000104jvoivkyr33	cms4k0opv000004jvoccgnrtk	A	cms37zfzn0005hgtd7gza4cvn
cms4k0osn000204jvfznf3l9v	cms4k0opv000004jvoccgnrtk	A	cms4ihelf000104jmwd1jh41x
cms4k0osn000304jvr427y3yx	cms4k0opv000004jvoccgnrtk	B	cms4if36v000004l8sq7n50wi
cms4k0osn000404jvb8x3tp1x	cms4k0opv000004jvoccgnrtk	B	cms3808b20008hgtdaxtqowy3
cms4k9a39000104jm5c2jf7oj	cms4k9a0m000004jmmy7x0e1c	A	cms37hxxp000004kv12xpq61b
cms4k9a39000204jmx77b8o4k	cms4k9a0m000004jmmy7x0e1c	A	cms4ifgek000004jm2hynvj8w
cms4k9a39000304jmoe2cjz95	cms4k9a0m000004jmmy7x0e1c	B	cms37zyg50007hgtdu0buusvi
cms4k9a39000404jmelankdn8	cms4k9a0m000004jmmy7x0e1c	B	cms37zki10006hgtd5877avlo
cms4kf9md000104jsinrhyf0g	cms4kf9jo000004jsil9npat8	A	cms37zfzn0005hgtd7gza4cvn
cms4kf9md000204js7cttjaz5	cms4kf9jo000004jsil9npat8	A	cms4ihelf000104jmwd1jh41x
cms4kf9md000304jsfmnqica9	cms4kf9jo000004jsil9npat8	B	cms37hxxp000004kv12xpq61b
cms4kf9md000404js3uw3oh1l	cms4kf9jo000004jsil9npat8	B	cms4ifgek000004jm2hynvj8w
cms4kijxc000104jvv8sh4erc	cms4kijup000004jvmyf3bp7f	A	cms37zki10006hgtd5877avlo
cms4kijxc000204jvl9z9ju8t	cms4kijup000004jvmyf3bp7f	A	cms37zyg50007hgtdu0buusvi
cms4kijxc000304jveniepzbq	cms4kijup000004jvmyf3bp7f	B	cms4if36v000004l8sq7n50wi
cms4kijxc000404jvg4resngz	cms4kijup000004jvmyf3bp7f	B	cms3808b20008hgtdaxtqowy3
cms4kjkx7000204jsbdbwbjdo	cms4kjkuk000104jsfpxtv5x8	A	cms37in3h000004i8eoz8ipze
cms4kjkx7000304jsw2zs17i2	cms4kjkuk000104jsfpxtv5x8	A	cms36j9tj000050tdrji7jgzy
cms4kjkx7000404jsjq1rw7cd	cms4kjkuk000104jsfpxtv5x8	B	cms4ihelf000104jmwd1jh41x
cms4kjkx7000504jsnefj7bz2	cms4kjkuk000104jsfpxtv5x8	B	cms37zfzn0005hgtd7gza4cvn
cms9y84bs000g04i5rikrduq5	3c2c1914-1e20-43f7-9270-19f21023f658	A	cms37in3h000004i8eoz8ipze
cms9y84bs000h04i5b7wajfp5	3c2c1914-1e20-43f7-9270-19f21023f658	A	cms36j9tj000050tdrji7jgzy
cms9y84bs000i04i5byex0yp2	3c2c1914-1e20-43f7-9270-19f21023f658	B	cms66zpp4000004i916qdj51o
cms9y84bs000j04i5mxgil0l5	3c2c1914-1e20-43f7-9270-19f21023f658	B	cms37zyg50007hgtdu0buusvi
cms9y84bs000k04i5puvqt3xe	18377367-84a9-4a8c-9c98-3dbfa05b4700	A	cms37zfzn0005hgtd7gza4cvn
cms9y84bs000l04i5k8hq8o11	18377367-84a9-4a8c-9c98-3dbfa05b4700	A	cms37zki10006hgtd5877avlo
cms9y84bs000m04i5rbgia105	18377367-84a9-4a8c-9c98-3dbfa05b4700	B	cms6henfo000004l6bztvhooq
cms9y84bs000n04i5q4lezqzc	18377367-84a9-4a8c-9c98-3dbfa05b4700	B	cms6hfgdv000004icc7dad5ve
cms9y84bs000o04i5q2ser4s3	f344a167-4923-46f0-9ebf-c105f540d58f	A	cms37zfzn0005hgtd7gza4cvn
cms9y84bs000p04i5ffs5ozoh	f344a167-4923-46f0-9ebf-c105f540d58f	A	cms37zki10006hgtd5877avlo
cms9y84bs000q04i5h46ornpc	f344a167-4923-46f0-9ebf-c105f540d58f	B	cms4if36v000004l8sq7n50wi
cms9y84bs000r04i5c1l132vx	f344a167-4923-46f0-9ebf-c105f540d58f	B	cms3808b20008hgtdaxtqowy3
cms9y84bs000w04i5bjkg3ab6	ee257a03-8b87-4d91-a61d-9df22e166002	A	cms37zfzn0005hgtd7gza4cvn
cms9y84bs000x04i5v65oje8s	ee257a03-8b87-4d91-a61d-9df22e166002	A	cms37zki10006hgtd5877avlo
cms9y84bs000y04i5k6d0e06y	ee257a03-8b87-4d91-a61d-9df22e166002	B	cms66zpp4000004i916qdj51o
cms9y84bs000z04i5m7kr4bhp	ee257a03-8b87-4d91-a61d-9df22e166002	B	cms37zyg50007hgtdu0buusvi
cms9y84bs001004i5udl16oz6	a61128b1-cac0-4f43-890c-c63194b90396	A	cms6henfo000004l6bztvhooq
cms9y84bs001104i582vg95cs	a61128b1-cac0-4f43-890c-c63194b90396	A	cms6hfgdv000004icc7dad5ve
cms9y84bs001204i517dihzm3	a61128b1-cac0-4f43-890c-c63194b90396	B	cms4if36v000004l8sq7n50wi
cms9y84bs001304i5onjjzijb	a61128b1-cac0-4f43-890c-c63194b90396	B	cms3808b20008hgtdaxtqowy3
cms9y84bs001404i5uoitz3bh	e36517b3-fbfd-4a99-8859-26024ff671b8	A	cms6henfo000004l6bztvhooq
cms9y84bs001504i5zvag0y14	e36517b3-fbfd-4a99-8859-26024ff671b8	A	cms6hfgdv000004icc7dad5ve
cms9y84bs001604i5jxmcllgd	e36517b3-fbfd-4a99-8859-26024ff671b8	B	cms37hxxp000004kv12xpq61b
cms9y84bs001704i5q7wx8isi	e36517b3-fbfd-4a99-8859-26024ff671b8	B	cms4ifgek000004jm2hynvj8w
cms9y84bs001804i5m3e8o5n3	4434902a-b2d3-470e-ad38-739944ee506b	A	cms6henfo000004l6bztvhooq
cms9y84bs001904i5gbyiopdd	4434902a-b2d3-470e-ad38-739944ee506b	A	cms6hfgdv000004icc7dad5ve
cms9y84bs001a04i5m8swb4w3	4434902a-b2d3-470e-ad38-739944ee506b	B	cms66zpp4000004i916qdj51o
cms9y84bs001b04i5ilvmj3ja	4434902a-b2d3-470e-ad38-739944ee506b	B	cms37zyg50007hgtdu0buusvi
cms9y84bs001c04i5cxj9u6bb	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	A	cms4if36v000004l8sq7n50wi
cms9y84bs001d04i55qort5vt	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	A	cms3808b20008hgtdaxtqowy3
cms9y84bs001e04i5zifv5yi3	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	B	cms37hxxp000004kv12xpq61b
cms9y84bs001f04i5tnoajyy7	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	B	cms4ifgek000004jm2hynvj8w
cms9y84bs001g04i5xawml4av	fd0d2451-feee-4657-a824-ad1e00874173	A	cms4if36v000004l8sq7n50wi
cms9y84bs001h04i5ourx4nie	fd0d2451-feee-4657-a824-ad1e00874173	A	cms3808b20008hgtdaxtqowy3
cms9y84bs001i04i5iaf6015m	fd0d2451-feee-4657-a824-ad1e00874173	B	cms66zpp4000004i916qdj51o
cms9y84bs001j04i5pno30fsc	fd0d2451-feee-4657-a824-ad1e00874173	B	cms37zyg50007hgtdu0buusvi
cms9y84bs001k04i5ajfr89nq	13701177-c88f-465e-8fdf-cc27dfa85c87	A	cms37hxxp000004kv12xpq61b
cms9y84bs001l04i50kw1dpvo	13701177-c88f-465e-8fdf-cc27dfa85c87	A	cms4ifgek000004jm2hynvj8w
cms9y84bs001m04i5i4xgm9pd	13701177-c88f-465e-8fdf-cc27dfa85c87	B	cms66zpp4000004i916qdj51o
cms9y84bt001n04i5moivmv0d	13701177-c88f-465e-8fdf-cc27dfa85c87	B	cms37zyg50007hgtdu0buusvi
cmsa0svik000204jxnmicw8k3	cmsa0svho000104jxfol8sj3q	A	cms37zfzn0005hgtd7gza4cvn
cmsa0svik000304jxc94cxlen	cmsa0svho000104jxfol8sj3q	A	cms37zki10006hgtd5877avlo
cmsa0svik000404jxa2pjt5x8	cmsa0svho000104jxfol8sj3q	B	cms37hxxp000004kv12xpq61b
cmsa0svik000504jxvvt8vtvh	cmsa0svho000104jxfol8sj3q	B	cms4ifgek000004jm2hynvj8w
\.


--
-- Data for Name: match_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_sets (id, "matchId", "setNumber", "sideAGames", "sideBGames", "tiebreakSideAPoints", "tiebreakSideBPoints") FROM stdin;
cmsa0n32g000004l4o90gmme3	51d6f2f4-0ea8-443b-9688-dc564327a866	1	6	0	\N	\N
cmsa0nl29000004jlmjcjrpdd	e36517b3-fbfd-4a99-8859-26024ff671b8	1	6	1	\N	\N
cmsa0rsqi000404jl0cu46try	ee257a03-8b87-4d91-a61d-9df22e166002	1	6	4	\N	\N
cmsa2amnq000004jowmi0kpq0	1d711576-4746-4724-a62b-d6dd93fa47d8	1	2	6	\N	\N
cmsa2ouuv000004l8qbv87rgp	f344a167-4923-46f0-9ebf-c105f540d58f	1	7	5	\N	\N
cmsa2w09c000204l8saifb7tt	13701177-c88f-465e-8fdf-cc27dfa85c87	1	7	6	8	6
cmsa4k4b1000004l06woe5ni5	a2f11b16-7e50-471f-a2e8-09c3cdf4117f	1	1	6	\N	\N
cmsa4ky2e000004jrhatvvrwl	4434902a-b2d3-470e-ad38-739944ee506b	1	6	3	\N	\N
cmsa4l6wq000204jrlndwkezu	8f453c54-e54b-4f6d-93dd-bd5351d89ba8	1	6	4	\N	\N
cmsa6zloe000004jxqa7n5gmh	3c2c1914-1e20-43f7-9270-19f21023f658	1	7	5	\N	\N
cmsa8hth9000004jj8tfbriic	061a18d3-b68c-4607-99d4-a51049ed93f7	1	6	2	\N	\N
cms4j11p2000504l4iyd578pn	cms4j0mo8000004l41m4cut27	1	6	4	\N	\N
cms4j7xxe000004laws91wx8d	cms4j4hrd000004jsmbpa99ge	1	4	6	\N	\N
cms4jc832000104lafz3w9h57	cms4jbtlk000004ji4rrklq3q	1	6	2	\N	\N
cms4jf7fz000a04jiwrlsqk88	cms4jesjc000504jiywmobz2c	1	6	3	\N	\N
cms4jiniq000b04jifp7fredt	cms4jhylk000204lajbn2pnu9	1	3	6	\N	\N
cms4k15dd000004layaefou1t	cms4k0opv000004jvoccgnrtk	1	7	5	\N	\N
cms4k9lyd000004ieb6pcieg2	cms4k9a0m000004jmmy7x0e1c	1	3	6	\N	\N
cms4kgb3j000004jslji94ypg	cms4kf9jo000004jsil9npat8	1	6	7	\N	\N
cms4kjycc000004l7w7sonp4f	cms4kjkuk000104jsfpxtv5x8	1	6	4	\N	\N
cms4kkemd000104l71mwf9zl0	cms4kijup000004jvmyf3bp7f	1	6	7	\N	\N
cmsa8ixdc000204jjg85usdeo	a61128b1-cac0-4f43-890c-c63194b90396	1	6	1	\N	\N
cmsa8jndu000004kyzj8tv0c3	cmsa0svho000104jxfol8sj3q	1	6	2	\N	\N
cmsa8mttc000404jjg2lt0pxr	18377367-84a9-4a8c-9c98-3dbfa05b4700	1	7	6	7	2
cmsa8qm24000604jj2j21kg3u	fd0d2451-feee-4657-a824-ad1e00874173	1	5	7	\N	\N
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, "tournamentId", round, "matchType", "scheduledDate", status, "winnerSide", "createdAt", "updatedAt", retired, "completedAt") FROM stdin;
cms4jesjc000504jiywmobz2c	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:53:03.096	2026-07-28 10:53:22.509	f	\N
cms4jhylk000204lajbn2pnu9	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 10:55:30.92	2026-07-28 10:56:03.311	f	\N
cms4k0opv000004jvoccgnrtk	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 11:10:04.579	2026-07-28 11:10:26.258	f	\N
cms4k9a0m000004jmmy7x0e1c	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:16:45.43	2026-07-28 11:17:00.996	f	\N
cms4j0mo8000004l41m4cut27	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:42:02.312	2026-07-28 10:42:21.901	f	\N
cms4j4hrd000004jsmbpa99ge	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 10:45:02.569	2026-07-28 10:47:43.585	f	\N
cms4jbtlk000004ji4rrklq3q	cms37eo8e0002hgtdbop2o98w	2 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 10:50:44.504	2026-07-28 10:51:03.373	f	\N
cms4kf9jo000004jsil9npat8	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:21:24.756	2026-07-28 11:22:13.518	f	\N
cms4kjkuk000104jsfpxtv5x8	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-28 11:24:46.028	2026-07-28 11:25:03.611	f	\N
cms4kijup000004jvmyf3bp7f	cms37eo8e0002hgtdbop2o98w	3 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	B	2026-07-28 11:23:58.081	2026-07-28 11:25:24.707	f	\N
51d6f2f4-0ea8-443b-9688-dc564327a866	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 06:54:14.36	f	\N
e36517b3-fbfd-4a99-8859-26024ff671b8	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 06:54:37.669	f	\N
ee257a03-8b87-4d91-a61d-9df22e166002	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 06:57:54.237	f	\N
1d711576-4746-4724-a62b-d6dd93fa47d8	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	B	2026-08-01 05:46:36.821	2026-08-01 07:40:32.446	f	\N
f344a167-4923-46f0-9ebf-c105f540d58f	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 07:51:36.26	f	\N
13701177-c88f-465e-8fdf-cc27dfa85c87	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 07:57:09.856	f	\N
a2f11b16-7e50-471f-a2e8-09c3cdf4117f	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	B	2026-08-01 05:46:36.821	2026-08-01 08:43:54.452	f	\N
4434902a-b2d3-470e-ad38-739944ee506b	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 08:44:33.018	f	\N
8f453c54-e54b-4f6d-93dd-bd5351d89ba8	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 08:44:44.478	f	\N
3c2c1914-1e20-43f7-9270-19f21023f658	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 09:51:56.046	f	\N
061a18d3-b68c-4607-99d4-a51049ed93f7	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 10:34:05.578	f	\N
a61128b1-cac0-4f43-890c-c63194b90396	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 10:34:57.268	f	\N
cmsa0svho000104jxfol8sj3q	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	\N	COMPLETED	A	2026-08-01 06:58:44.46	2026-08-01 10:35:30.995	f	\N
18377367-84a9-4a8c-9c98-3dbfa05b4700	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	A	2026-08-01 05:46:36.821	2026-08-01 10:37:59.284	f	\N
fd0d2451-feee-4657-a824-ad1e00874173	cms38gx1f000004jnvhqe1ilw	\N	DOUBLES	2026-08-01 00:00:00	COMPLETED	B	2026-08-01 05:46:36.821	2026-08-01 10:40:55.856	f	\N
\.


--
-- Data for Name: news_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_posts (id, title, body, "authorId", "createdAt", "updatedAt") FROM stdin;
cms49hbv6000004lb1e5s98g6	Запуск сайту!	Це перша публікація, але не остання)	cms352tfv0000e0tdmfc0urb6	2026-07-28 06:15:05.298	2026-07-28 12:04:53.845
cms8p21a5000004kv2u266b2u	🎾 Парний турнір 2×2 вже цієї суботи!	Цієї суботи наш клуб стане ареною захопливих тенісних баталій — на вас чекає парний турнір 2×2! 💥\r\n\r\n🕘 Старт о 9:00\r\n\r\nПопереду — яскраві розіграші, напружені матчі, командна боротьба та море емоцій. Учасники вже готові виходити на корт, а ми запрошуємо всіх уболівальників підтримати своїх фаворитів і провести ранок у чудовій спортивній атмосфері.\r\n\r\nДо зустрічі на кортах! 🎾🙌	cms352tfv0000e0tdmfc0urb6	2026-07-31 08:42:10.301	2026-07-31 08:42:10.301
cmsadl8wd000004l2ab79bc4a	Підсумки парного турніру 2×2 🎾	Сьогодні, 1 серпня, у нашому клубі відбувся парний турнір 2×2, який подарував учасникам та вболівальникам багато яскравих розіграшів, напружених матчів і спортивних емоцій.\r\n\r\nУ турнірі взяли участь 12 гравців, які сформували 6 пар. Протягом дня кожна команда провела по 5 матчів, демонструючи характер, командну взаємодію та жагу до перемоги.\r\n\r\n🏆 Переможцями турніру стали Ілля Терехов та Ганна Терехова, які здобули 4 перемоги у 5 матчах та показали найкращу різницю виграних геймів (30:14).\r\n\r\n🥈 Друге місце посіли Сергій Гільченко та Денис Іоганов — також 4 перемоги у 5 матчах, із різницею геймів 27:17.\r\n\r\n🥉 Третє місце вибороли Олег Матушевський та Олена Матушевська, завершивши турнір із 4 перемогами та різницею геймів 30:23.\r\n\r\nВітаємо переможців і дякуємо всім учасникам за чесну боротьбу, чудову атмосферу та любов до тенісу! До зустрічі на наступних турнірах! 🎾👏	cms352tfv0000e0tdmfc0urb6	2026-08-01 12:56:43.597	2026-08-01 12:56:43.597
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, name, email, "userId", "createdAt", gender) FROM stdin;
cms4if36v000004l8sq7n50wi	Теребіж Віктор	terebizhvictor@gmail.com	cmsae1urh000004i9rgpt7v0s	2026-07-28 10:25:17.287	MALE
cms36j9tj000050tdrji7jgzy	Гільченко Сергій	sdalin777@gmail.com	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:04:50.935	MALE
cms378xqi0001hgtdr6l6sxef	Короткова Маргарита	mkorobok07@gmail.com	cms37qbcp000004jldlm5roy0	2026-07-27 12:24:48.33	FEMALE
cms3808b20008hgtdaxtqowy3	Андрєєв Олександр	\N	\N	2026-07-27 12:46:01.742	MALE
cms37zyg50007hgtdu0buusvi	Данілюк Євген	\N	\N	2026-07-27 12:45:48.965	MALE
cms37zki10006hgtd5877avlo	Матушевська Олена	\N	\N	2026-07-27 12:45:30.889	FEMALE
cms37zfzn0005hgtd7gza4cvn	Матушевський Олег	\N	\N	2026-07-27 12:45:25.043	MALE
cms4ifgek000004jm2hynvj8w	Кулеш Ірина	\N	\N	2026-07-28 10:25:34.412	FEMALE
cms4ihelf000104jmwd1jh41x	Баранова Олександра	\N	\N	2026-07-28 10:27:05.379	FEMALE
cms37hxxp000004kv12xpq61b	Демʼянішин Тарас	taras.demyanyshyn@gmail.com	cmsa8ydwk000004l4hoktox9w	2026-07-27 12:31:48.493	MALE
cms66zpp4000004i916qdj51o	Хищенко Олександр	\N	\N	2026-07-29 14:40:56.536	MALE
cms6henfo000004l6bztvhooq	Терехов Ілля	\N	\N	2026-07-29 19:32:29.605	MALE
cms6hfgdv000004icc7dad5ve	Терехова Ганна	\N	\N	2026-07-29 19:33:07.123	FEMALE
cms37in3h000004i8eoz8ipze	Іоганов Денис	deni220585@gmail.com	cms7jjux1000004ldbqqk9i7v	2026-07-27 12:32:21.101	MALE
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions ("sessionToken", "userId", expires) FROM stdin;
5b86e542-5203-4e32-8d66-c5b042264593	cmsae1urh000004i9rgpt7v0s	2026-08-31 13:09:38.454
a909d466-22e6-442e-9555-0cf7c3880e3e	cms352tfv0000e0tdmfc0urb6	2026-08-26 16:44:51.091
2f432af2-eb09-4f2d-b050-a0498d92880d	cms7jjux1000004ldbqqk9i7v	2026-08-30 18:30:30.615
8e39b005-2705-4b71-82a0-66007a9aece9	cmsa8ydwk000004l4hoktox9w	2026-08-31 10:46:58.57
728eca72-df97-4d9f-8515-8bc09ca2064f	cms37qbcp000004jldlm5roy0	2026-08-31 11:51:30.642
a90599cf-120f-4b52-8bef-a0c2dc39e1fc	cmsaba21r000004ifvn9ov42j	2026-08-31 11:52:02.299
1eda930d-5ce8-4a3c-b235-ddab627e41a8	cms352tfv0000e0tdmfc0urb6	2026-09-01 14:55:27.808
874fa4f3-af9b-4483-b446-ca62baca9f62	cms352tfv0000e0tdmfc0urb6	2026-09-01 18:57:37.231
\.


--
-- Data for Name: tournament_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournament_participants (id, "tournamentId", "playerId", seed, "joinedAt") FROM stdin;
cms37f2qg0003hgtdh1afxqao	cms37eo8e0002hgtdbop2o98w	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 12:29:34.744
cms381l670009hgtd16ewm01w	cms37eo8e0002hgtdbop2o98w	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 12:47:05.071
cms381vpa000chgtdn8l54hlp	cms37eo8e0002hgtdbop2o98w	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 12:47:18.718
cms38ogf3000104l7utvevswm	cms38gx1f000004jnvhqe1ilw	cms37zki10006hgtd5877avlo	\N	2026-07-27 13:04:51.999
cms38oj4y000204js1on3helm	cms38gx1f000004jnvhqe1ilw	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 13:04:55.522
cms38oluz000004jyplksx1tv	cms38gx1f000004jnvhqe1ilw	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 13:04:59.051
cms38oqn2000304l74y5ktx01	cms38gx1f000004jnvhqe1ilw	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 13:05:05.246
cms4ilucf000004jj1ae99gtx	cms38gx1f000004jnvhqe1ilw	cms4ifgek000004jm2hynvj8w	\N	2026-07-28 10:30:32.415
cms6700lg000104i97q209ot9	cms38gx1f000004jnvhqe1ilw	cms66zpp4000004i916qdj51o	1	2026-07-29 14:41:10.66
cms6hg7vg000104l6elsxywxe	cms38gx1f000004jnvhqe1ilw	cms6henfo000004l6bztvhooq	1	2026-07-29 19:33:42.748
cms4iikhw000304jm5f0rz8qo	cms37eo8e0002hgtdbop2o98w	cms4ifgek000004jm2hynvj8w	\N	2026-07-28 10:27:59.684
cms4iikpr000404jma6rgjehm	cms37eo8e0002hgtdbop2o98w	cms4ihelf000104jmwd1jh41x	\N	2026-07-28 10:27:59.967
cms37kqdq000104i80lztwuup	cms37eo8e0002hgtdbop2o98w	cms37in3h000004i8eoz8ipze	1	2026-07-27 12:33:58.67
cms37ksui000104kvulzahp4m	cms37eo8e0002hgtdbop2o98w	cms37hxxp000004kv12xpq61b	1	2026-07-27 12:34:01.866
cms381qea000ahgtdk8yd75q7	cms37eo8e0002hgtdbop2o98w	cms37zfzn0005hgtd7gza4cvn	1	2026-07-27 12:47:11.842
cms381t7e000bhgtdl8imb9w8	cms37eo8e0002hgtdbop2o98w	cms37zki10006hgtd5877avlo	1	2026-07-27 12:47:15.483
cms4iik9u000204jms1mucsbh	cms37eo8e0002hgtdbop2o98w	cms4if36v000004l8sq7n50wi	1	2026-07-28 10:27:59.394
cms6hg83e000204l67d5xwwe1	cms38gx1f000004jnvhqe1ilw	cms6hfgdv000004icc7dad5ve	\N	2026-07-29 19:33:43.034
cms38oass000004jstg99u8xe	cms38gx1f000004jnvhqe1ilw	cms37in3h000004i8eoz8ipze	1	2026-07-27 13:04:44.716
cms38odmo000104jsx9nw55y5	cms38gx1f000004jnvhqe1ilw	cms37hxxp000004kv12xpq61b	1	2026-07-27 13:04:48.384
cms38ooh5000204l7b6447s1c	cms38gx1f000004jnvhqe1ilw	cms37zfzn0005hgtd7gza4cvn	1	2026-07-27 13:05:02.441
cms4ilukf000104jjkculx3ta	cms38gx1f000004jnvhqe1ilw	cms4if36v000004l8sq7n50wi	1	2026-07-28 10:30:32.703
\.


--
-- Data for Name: tournaments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournaments (id, name, description, format, status, "startDate", "endDate", "createdById", "createdAt", "updatedAt", surface) FROM stdin;
cms37eo8e0002hgtdbop2o98w	18.07.2026	Парний турнір за участю 5 команд	DOUBLES	COMPLETED	2026-07-18 00:00:00	2026-07-18 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:29:15.95	2026-07-28 10:43:37.049	CLAY
cms38gx1f000004jnvhqe1ilw	01.08.2026	\N	DOUBLES	COMPLETED	2026-08-01 00:00:00	2026-08-01 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:59:00.291	2026-08-01 10:42:40.061	CLAY
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, role, "createdAt") FROM stdin;
cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	sdalin777@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocLcfuanMio9VWyqGfu-YaGUzyZ_NqbMmmYp1wAaviGsXHe-3EjQ=s96-c	ADMIN	2026-07-27 11:24:03.595
cms37qbcp000004jldlm5roy0	Margot	mkorobok07@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJPSzXFcg6hdHql5GfjVpzogbhZ7svNGapc0nzaMivG0c8iFg=s96-c	MEMBER	2026-07-27 12:38:19.129
cms7jjux1000004ldbqqk9i7v	Денис Иоганов	deni220585@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJLU38gTlJlj8NllMyKRgz_AwwHVq8tBjf7rb3lL5KY7dK_53Rq=s96-c	ADMIN	2026-07-30 13:20:17.989
cmsae1urh000004i9rgpt7v0s	TEREM BEATS	terebizhvictor@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocIluVlumQxhQLhNaQudgpg1XvuFIrDJcZWTZzqV9cJ8zZXpismS=s96-c	MEMBER	2026-08-01 13:09:38.429
cmsa8ydwk000004l4hoktox9w	Taras Demyanyshyn	taras.demyanyshyn@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJ7_zV7h6CTPPYgPwFlaQySv2-kAgaTs7LbfnveWxF0KaxUjg=s96-c	MEMBER	2026-08-01 10:46:58.532
cmsaba21r000004ifvn9ov42j	Анастасия Полищук	nastia240120018@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocLriHd7SweiP8FTyJ4VHzMktOUcSEZJOCFHvsqwynzuZ0QdGeZs=s96-c	MEMBER	2026-08-01 11:52:02.271
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (provider, "providerAccountId");


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: match_players match_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_pkey PRIMARY KEY (id);


--
-- Name: match_sets match_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT match_sets_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: news_posts news_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT news_posts_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: tournament_participants tournament_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT tournament_participants_pkey PRIMARY KEY (id);


--
-- Name: tournaments tournaments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (identifier, token);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: match_players_matchId_side_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_players_matchId_side_playerId_key" ON public.match_players USING btree ("matchId", side, "playerId");


--
-- Name: match_players_playerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "match_players_playerId_idx" ON public.match_players USING btree ("playerId");


--
-- Name: match_sets_matchId_setNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_sets_matchId_setNumber_key" ON public.match_sets USING btree ("matchId", "setNumber");


--
-- Name: matches_tournamentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matches_tournamentId_idx" ON public.matches USING btree ("tournamentId");


--
-- Name: players_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX players_email_key ON public.players USING btree (email);


--
-- Name: players_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "players_userId_key" ON public.players USING btree ("userId");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sessions_userId_idx" ON public.sessions USING btree ("userId");


--
-- Name: tournament_participants_playerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tournament_participants_playerId_idx" ON public.tournament_participants USING btree ("playerId");


--
-- Name: tournament_participants_tournamentId_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tournament_participants_tournamentId_playerId_key" ON public.tournament_participants USING btree ("tournamentId", "playerId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: match_players match_players_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_players match_players_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_sets match_sets_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT "match_sets_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matches matches_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT "matches_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_posts news_posts_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT "news_posts_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: players players_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT "players_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournaments tournaments_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT "tournaments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict epGafom1Iwrf8DY5I3E2PluyQ7GXSXy0ALnvRdwWGIdva0mfWSKP4PNpV9B1m1Y

