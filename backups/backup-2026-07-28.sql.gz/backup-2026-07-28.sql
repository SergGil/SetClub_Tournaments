--
-- PostgreSQL database dump
--

\restrict 75P2m3Hgdxr0aqtrp2nbAkq4h6NifcGcouRrcJNOUyeTu7pMumki0UzfKB5WZVk

-- Dumped from database version 18.4 (df16b3c)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CourtSurface; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CourtSurface" AS ENUM (
    'CLAY',
    'GRASS',
    'HARD'
);


--
-- Name: Gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE'
);


--
-- Name: MatchSide; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchSide" AS ENUM (
    'A',
    'B'
);


--
-- Name: MatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchStatus" AS ENUM (
    'SCHEDULED',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: MatchType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MatchType" AS ENUM (
    'SINGLES',
    'DOUBLES'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBER'
);


--
-- Name: TournamentFormat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentFormat" AS ENUM (
    'SINGLES',
    'DOUBLES',
    'MIXED'
);


--
-- Name: TournamentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TournamentStatus" AS ENUM (
    'UPCOMING',
    'ONGOING',
    'COMPLETED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: match_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_players (
    id text NOT NULL,
    "matchId" text NOT NULL,
    side public."MatchSide" NOT NULL,
    "playerId" text NOT NULL
);


--
-- Name: match_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_sets (
    id text NOT NULL,
    "matchId" text NOT NULL,
    "setNumber" integer NOT NULL,
    "sideAGames" integer NOT NULL,
    "sideBGames" integer NOT NULL
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    round text,
    "matchType" public."MatchType" NOT NULL,
    "scheduledDate" timestamp(3) without time zone,
    status public."MatchStatus" DEFAULT 'SCHEDULED'::public."MatchStatus" NOT NULL,
    "winnerSide" public."MatchSide",
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: news_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_posts (
    id text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gender public."Gender"
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: tournament_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_participants (
    id text NOT NULL,
    "tournamentId" text NOT NULL,
    "playerId" text NOT NULL,
    seed integer,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tournaments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    format public."TournamentFormat" NOT NULL,
    status public."TournamentStatus" DEFAULT 'UPCOMING'::public."TournamentStatus" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    surface public."CourtSurface" DEFAULT 'CLAY'::public."CourtSurface" NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    role public."Role" DEFAULT 'MEMBER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b6a4f99f-a8b6-4c06-85a9-4d39ff635363	f553e02dfb0e13179102a3d6a50b294e89fc66249f9020046762c435b7f90e80	2026-07-27 11:02:53.954768+00	20260727110248_init	\N	\N	2026-07-27 11:02:49.941974+00	1
799328ab-1eac-4efb-bbae-6bf65b4961b5	c7b4dda0637311e0d3ff7204537883b82173e06b1a8857d00afeb76e037b18a1	2026-07-27 13:46:12.42331+00	20260727134610_add_player_gender	\N	\N	2026-07-27 13:46:11.509481+00	1
66315c66-29d4-4095-ac76-7fe3013441c7	ae7461c9fc5e8e4dadcabdd436d8f0e8a5b479b756c9164d8a1c302355f611c2	2026-07-28 06:02:57.786793+00	20260728060256_add_news_posts	\N	\N	2026-07-28 06:02:57.031249+00	1
2dfe2022-3b79-4980-a314-86665a3e4e98	66a25451567a67f105fa46bc65c4172f8b855e0896697778a559e03935a6b194	2026-07-28 06:17:37.333148+00	20260728061735_add_tournament_surface	\N	\N	2026-07-28 06:17:36.237221+00	1
20a897a3-d0ba-455c-8b98-d3f36e3515d7	eae60b8cd55c17585d7781a1a3ee65756f2e2273db1aaa416ebf80c487a642fb	2026-07-28 06:24:09.571991+00	20260728062408_default_surface_to_clay	\N	\N	2026-07-28 06:24:08.684057+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts ("userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
cms352tfv0000e0tdmfc0urb6	oidc	google	101751805477113985549	\N	ya29.a0ARGnu0YRk5ColLBpT3FpMxPrdj_gtcCtPNeI6WVbnNgS43z9mOeRIBKb7FsJ_Imke6bLdkXuXRHYCQVXhpE_oR4TtLw7ST8wnAWMkvqj010sAgyxMUY0zQxrZDClifeOVogOIiZZ8oGNO3d8bRLUXaNYcFWzvqaDW1sXRM3xkDwbAKDTk-_hGtAbTkGpzAxEwSHdN7IaCgYKAbwSARQSFQHGX2Mi_5LX2G3ozGMTtMchGKYS8g0206	1785155041	bearer	https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDE3NTE4MDU0NzcxMTM5ODU1NDkiLCJlbWFpbCI6InNkYWxpbjc3N0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6InZQcGt2a3JUTHlKajYtWUhjZ1ozVGciLCJuYW1lIjoiU2VyaGlpIEhpbGNoZW5rbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMY2Z1YW5NaW85Vld5cUdmdS1ZYUdVenlaX05xYk1tbVlwMXdBYXZpR3NYSGUtM0VqUT1zOTYtYyIsImdpdmVuX25hbWUiOiJTZXJoaWkiLCJmYW1pbHlfbmFtZSI6IkhpbGNoZW5rbyIsImlhdCI6MTc4NTE1MTQ0MiwiZXhwIjoxNzg1MTU1MDQyfQ.nVIwR1ybmWjwKGlBnKYYrQQD6jFswKVBuP5gM04AOgrEpj0SpNNpRXSlwLV8Sk-OyhiTRC7UMo59SJJZol0Z6JNi8Krzw5LY6jP9Ih3tziJkxm_N2Zrhy6cfF9N0d9iMfOqd8EINAa6hdBNzlbg2gpnfS3K4YwRPxgGmSqSOGQ9W15WIg8jJNZAqw0CuUnShYNjoug-jANK6jM5lDjKtdjahoo-FFugdWXcHwiDLycXr6ocG7ERGSwtPvQB5h058XlpU3CEoONq95hRSQCdc47iEheMTAvh_4RumNhzYgr5lBFC-m9dyUyiHaGLYb6C3aNb-DQdZEdZPElYdbN0YFQ	\N
cms37qbcp000004jldlm5roy0	oidc	google	100352920718100813505	\N	ya29.a0ARGnu0YMtGWrww8zyMopkaAnq-3iPaPjyxo4JQ4hJ9ASGhxHQ7ftjkafyzuCwa7EG2D3wHXpTTQJUm7yBnNe47VrDyqA0TSyPB9LR8G3zzT50D-z7kvhCvfn5XoM_cKcY3Z_4wRUOrYaSB0TqXxsKsctmZ5-9PXNDI4CCowWdudBXk49_3BBzOluObPZPhTn1MzJfzUaCgYKAfcSARcSFQHGX2Mi2TglX0TCH3tDvaymIA_K-A0206	1785159497	bearer	https://www.googleapis.com/auth/userinfo.email openid https://www.googleapis.com/auth/userinfo.profile	eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2NTE5NzAwMTE5ODEtY2xyaWg1cDdrYzljZzVsN3V0MjY3MmU4aXE0YnMxcHMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDAzNTI5MjA3MTgxMDA4MTM1MDUiLCJlbWFpbCI6Im1rb3JvYm9rMDdAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJoQ3hTUUFaNzdpQXlFSGNxRHlYLWN3IiwibmFtZSI6Ik1hcmdvdCIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NKUFN6WEZjZzZoZEhxbDVHZmpWcHpvZ2JoWjdzdk5HYXBjMG56YU1pdkcwYzhpRmc9czk2LWMiLCJnaXZlbl9uYW1lIjoiTWFyZ290IiwiaWF0IjoxNzg1MTU1ODk4LCJleHAiOjE3ODUxNTk0OTh9.lW9mGIQUl2RNf8zzFJhyOKKy7HJH1sT8W3djk5-86rDrcYe_ethUKgsNZio3o53kYDyRlKJ05qNBdP-j_zoYh4MkxHpGdNiDFIwz1bKZCd-BVSsow-WtTfxpsxif35mdZvpWqwCHaUdbVJufv820VAM0UHy6goxrCFfua_KG8PjVSMn1lAmC9Gf19BfP5r00g97--978HGqZvcsZ_rboPc1BKNRIZm6UI50tLWoItouhML2zsrPA6btLNdXcfO9AINWVDP-EGocUtBKcTHi-YW340tq9dO0whkEDbsNf-7cwnHsPlIYetWU_HjtzxlyP0H4GzEjIsvnQjUqhdgKlNw	\N
\.


--
-- Data for Name: match_players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_players (id, "matchId", side, "playerId") FROM stdin;
cms37mqph000104l7bmy8cqkb	cms37mqmp000004l7equajso1	A	cms36j9tj000050tdrji7jgzy
cms37mqph000204l78316rthw	cms37mqmp000004l7equajso1	A	cms378xqi0001hgtdr6l6sxef
cms37mqph000304l79que0e57	cms37mqmp000004l7equajso1	B	cms37in3h000004i8eoz8ipze
cms37mqph000404l7yvlei764	cms37mqmp000004l7equajso1	B	cms37hxxp000004kv12xpq61b
cms382fn4000ehgtd4nv7ml6y	cms382fk5000dhgtdfxybhx74	A	cms37zki10006hgtd5877avlo
cms382fn4000fhgtdckxfl8hc	cms382fk5000dhgtdfxybhx74	A	cms37zyg50007hgtdu0buusvi
cms382fn4000ghgtdhrsx7m99	cms382fk5000dhgtdfxybhx74	B	cms37zfzn0005hgtd7gza4cvn
cms382fn4000hhgtdvvenr0ab	cms382fk5000dhgtdfxybhx74	B	cms3808b20008hgtdaxtqowy3
cms38wsvz000204jyld8b2n6k	cms38wstc000104jyi9g9l6xz	A	cms37zfzn0005hgtd7gza4cvn
cms38wsvz000304jyhyjdk856	cms38wstc000104jyi9g9l6xz	A	cms37in3h000004i8eoz8ipze
cms38wsvz000404jyuir3lyr4	cms38wstc000104jyi9g9l6xz	B	cms378xqi0001hgtdr6l6sxef
cms38wsvz000504jy55t0a2h4	cms38wstc000104jyi9g9l6xz	B	cms3808b20008hgtdaxtqowy3
cms38z1sp000104k0r6i8p0zw	cms38z1q2000004k06kcpzuq2	A	cms37hxxp000004kv12xpq61b
cms38z1sp000204k0yic2fxi5	cms38z1q2000004k06kcpzuq2	A	cms378xqi0001hgtdr6l6sxef
cms38z1sp000304k0tvd1qccl	cms38z1q2000004k06kcpzuq2	B	cms3808b20008hgtdaxtqowy3
cms38z1sp000404k0k5lcm7vo	cms38z1q2000004k06kcpzuq2	B	cms36j9tj000050tdrji7jgzy
cms39ehc3000404jombld7ucg	cms39eh9h000304jo9c545kg1	A	cms36j9tj000050tdrji7jgzy
cms39ehc3000504jobjhjp293	cms39eh9h000304jo9c545kg1	B	cms378xqi0001hgtdr6l6sxef
cms39mhyw000104jp57dl2u36	cms39mhw9000004jpmu7dmedh	A	cms37in3h000004i8eoz8ipze
cms39mhyw000204jpvhf79sp3	cms39mhw9000004jpmu7dmedh	B	cms37zki10006hgtd5877avlo
cms3i3e45000104k0mjqyzsyz	cms3i3e1e000004k0d8jq4nw8	A	cms37hxxp000004kv12xpq61b
cms3i3e45000204k0ys8b90m6	cms3i3e1e000004k0d8jq4nw8	A	cms37zyg50007hgtdu0buusvi
cms3i3e45000304k0v61b4kqv	cms3i3e1e000004k0d8jq4nw8	B	cms37zfzn0005hgtd7gza4cvn
cms3i3e45000404k0vxe825d5	cms3i3e1e000004k0d8jq4nw8	B	cms3808b20008hgtdaxtqowy3
cms3i3ec5000604k0ikkcni3t	cms3i3e9j000504k06nwltg80	A	cms37hxxp000004kv12xpq61b
cms3i3ec5000704k0yfhnbl5n	cms3i3e9j000504k06nwltg80	A	cms37zyg50007hgtdu0buusvi
cms3i3ec5000804k0aqffdrc8	cms3i3e9j000504k06nwltg80	B	cms37zki10006hgtd5877avlo
cms3i3ec5000904k07kxipens	cms3i3e9j000504k06nwltg80	B	cms378xqi0001hgtdr6l6sxef
cms3i3ek0000b04k03kb0bt96	cms3i3ehe000a04k06ecw0cxf	A	cms37hxxp000004kv12xpq61b
cms3i3ek0000c04k0y6bvz13o	cms3i3ehe000a04k06ecw0cxf	A	cms37zyg50007hgtdu0buusvi
cms3i3ek0000d04k0auhsuo25	cms3i3ehe000a04k06ecw0cxf	B	cms37in3h000004i8eoz8ipze
cms3i3ek0000e04k0zorwdc4p	cms3i3ehe000a04k06ecw0cxf	B	cms36j9tj000050tdrji7jgzy
cms3i3eru000g04k0ksxrsg5x	cms3i3ep8000f04k0s6mfr4k3	A	cms37zfzn0005hgtd7gza4cvn
cms3i3eru000h04k0wkl2fr4a	cms3i3ep8000f04k0s6mfr4k3	A	cms3808b20008hgtdaxtqowy3
cms3i3eru000i04k053ml1gar	cms3i3ep8000f04k0s6mfr4k3	B	cms37zki10006hgtd5877avlo
cms3i3eru000j04k0r01uspdr	cms3i3ep8000f04k0s6mfr4k3	B	cms378xqi0001hgtdr6l6sxef
cms3i3ezp000l04k00vc997id	cms3i3ex2000k04k0j12p3eve	A	cms37zfzn0005hgtd7gza4cvn
cms3i3ezp000m04k0jy26pzn2	cms3i3ex2000k04k0j12p3eve	A	cms3808b20008hgtdaxtqowy3
cms3i3ezp000n04k0qblez6xm	cms3i3ex2000k04k0j12p3eve	B	cms37in3h000004i8eoz8ipze
cms3i3ezp000o04k0sj7av9i1	cms3i3ex2000k04k0j12p3eve	B	cms36j9tj000050tdrji7jgzy
cms3i3f7j000q04k0xhbdl2ej	cms3i3f4x000p04k0cbw4k45e	A	cms37zki10006hgtd5877avlo
cms3i3f7j000r04k0a9u3g73h	cms3i3f4x000p04k0cbw4k45e	A	cms378xqi0001hgtdr6l6sxef
cms3i3f7j000s04k0e2i082e8	cms3i3f4x000p04k0cbw4k45e	B	cms37in3h000004i8eoz8ipze
cms3i3f7j000t04k0819d36h2	cms3i3f4x000p04k0cbw4k45e	B	cms36j9tj000050tdrji7jgzy
\.


--
-- Data for Name: match_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_sets (id, "matchId", "setNumber", "sideAGames", "sideBGames") FROM stdin;
cms37n5p9000204kvbrxyw0p1	cms37mqmp000004l7equajso1	1	6	0
cms383q5y000jhgtdr9r434cs	cms382fk5000dhgtdfxybhx74	1	7	6
cms39mvlu000c04jo2pketznw	cms39mhw9000004jpmu7dmedh	1	6	4
cms3aj8r8000004l1v6814k9n	cms39eh9h000304jo9c545kg1	1	3	6
cms3aj8r8000104l1jrt21zh5	cms39eh9h000304jo9c545kg1	2	7	6
cms3aj8r8000204l1oanxljvp	cms39eh9h000304jo9c545kg1	3	2	6
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, "tournamentId", round, "matchType", "scheduledDate", status, "winnerSide", "createdAt", "updatedAt") FROM stdin;
cms37mqmp000004l7equajso1	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	2026-07-18 00:00:00	COMPLETED	A	2026-07-27 12:35:32.305	2026-07-27 12:35:51.939
cms382fk5000dhgtdfxybhx74	cms37eo8e0002hgtdbop2o98w	1 коло	DOUBLES	\N	COMPLETED	A	2026-07-27 12:47:44.453	2026-07-27 12:48:44.961
cms38wstc000104jyi9g9l6xz	cms37eo8e0002hgtdbop2o98w	1/4	DOUBLES	2026-07-18 00:00:00	SCHEDULED	\N	2026-07-27 13:11:21.312	2026-07-27 13:11:21.312
cms38z1q2000004k06kcpzuq2	cms37eo8e0002hgtdbop2o98w	\N	DOUBLES	2026-07-18 00:00:00	SCHEDULED	\N	2026-07-27 13:13:06.17	2026-07-27 13:13:06.17
cms39mhw9000004jpmu7dmedh	cms397k82000004kyw5azr036	2 коло	SINGLES	2026-08-01 00:00:00	COMPLETED	A	2026-07-27 13:31:20.217	2026-07-27 13:31:38.08
cms39eh9h000304jo9c545kg1	cms39cobc000004ldazr6n13i	Фінал	SINGLES	2025-10-01 00:00:00	COMPLETED	B	2026-07-27 13:25:06.149	2026-07-27 13:56:48.114
cms3i3e1e000004k0d8jq4nw8	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:25.298	2026-07-27 17:28:25.298
cms3i3e9j000504k06nwltg80	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:25.591	2026-07-27 17:28:25.591
cms3i3ehe000a04k06ecw0cxf	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:25.874	2026-07-27 17:28:25.874
cms3i3ep8000f04k0s6mfr4k3	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:26.156	2026-07-27 17:28:26.156
cms3i3ex2000k04k0j12p3eve	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:26.438	2026-07-27 17:28:26.438
cms3i3f4x000p04k0cbw4k45e	cms3b8xbj000004jm8t35qyuz	\N	DOUBLES	2026-07-27 00:00:00	SCHEDULED	\N	2026-07-27 17:28:26.721	2026-07-27 17:28:26.721
\.


--
-- Data for Name: news_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_posts (id, title, body, "authorId", "createdAt", "updatedAt") FROM stdin;
cms49hbv6000004lb1e5s98g6	Відкриття сайту!	Це перша публікація, але не остання)	cms352tfv0000e0tdmfc0urb6	2026-07-28 06:15:05.298	2026-07-28 06:15:05.298
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, name, email, "userId", "createdAt", gender) FROM stdin;
cms37hxxp000004kv12xpq61b	Тарас	\N	\N	2026-07-27 12:31:48.493	\N
cms37zfzn0005hgtd7gza4cvn	Олег	\N	\N	2026-07-27 12:45:25.043	\N
cms37zki10006hgtd5877avlo	Лєна	\N	\N	2026-07-27 12:45:30.889	\N
cms3808b20008hgtdaxtqowy3	Олександр	\N	\N	2026-07-27 12:46:01.742	\N
cms36j9tj000050tdrji7jgzy	Гільченко Сергій	sdalin777@gmail.com	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:04:50.935	MALE
cms37zyg50007hgtdu0buusvi	Євген	\N	\N	2026-07-27 12:45:48.965	MALE
cms378xqi0001hgtdr6l6sxef	Короткова Маргарита	mkorobok07@gmail.com	cms37qbcp000004jldlm5roy0	2026-07-27 12:24:48.33	FEMALE
cms37in3h000004i8eoz8ipze	Денис Іоганов	\N	\N	2026-07-27 12:32:21.101	MALE
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions ("sessionToken", "userId", expires) FROM stdin;
728eca72-df97-4d9f-8515-8bc09ca2064f	cms37qbcp000004jldlm5roy0	2026-08-26 12:38:19.334
acfcca9a-640a-4b2d-95cf-31f0c4250e33	cms352tfv0000e0tdmfc0urb6	2026-08-26 12:56:30.131
a909d466-22e6-442e-9555-0cf7c3880e3e	cms352tfv0000e0tdmfc0urb6	2026-08-26 16:44:51.091
874fa4f3-af9b-4483-b446-ca62baca9f62	cms352tfv0000e0tdmfc0urb6	2026-08-26 17:03:40.225
\.


--
-- Data for Name: tournament_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournament_participants (id, "tournamentId", "playerId", seed, "joinedAt") FROM stdin;
cms37f2qg0003hgtdh1afxqao	cms37eo8e0002hgtdbop2o98w	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 12:29:34.744
cms37f86u0004hgtddbeut41p	cms37eo8e0002hgtdbop2o98w	cms378xqi0001hgtdr6l6sxef	\N	2026-07-27 12:29:41.814
cms37kqdq000104i80lztwuup	cms37eo8e0002hgtdbop2o98w	cms37in3h000004i8eoz8ipze	\N	2026-07-27 12:33:58.67
cms37ksui000104kvulzahp4m	cms37eo8e0002hgtdbop2o98w	cms37hxxp000004kv12xpq61b	\N	2026-07-27 12:34:01.866
cms381l670009hgtd16ewm01w	cms37eo8e0002hgtdbop2o98w	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 12:47:05.071
cms381qea000ahgtdk8yd75q7	cms37eo8e0002hgtdbop2o98w	cms37zfzn0005hgtd7gza4cvn	\N	2026-07-27 12:47:11.842
cms381t7e000bhgtdl8imb9w8	cms37eo8e0002hgtdbop2o98w	cms37zki10006hgtd5877avlo	\N	2026-07-27 12:47:15.483
cms381vpa000chgtdn8l54hlp	cms37eo8e0002hgtdbop2o98w	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 12:47:18.718
cms38o4ny000004l7z9ur3rju	cms38gx1f000004jnvhqe1ilw	cms378xqi0001hgtdr6l6sxef	\N	2026-07-27 13:04:36.766
cms38oass000004jstg99u8xe	cms38gx1f000004jnvhqe1ilw	cms37in3h000004i8eoz8ipze	\N	2026-07-27 13:04:44.716
cms38odmo000104jsx9nw55y5	cms38gx1f000004jnvhqe1ilw	cms37hxxp000004kv12xpq61b	\N	2026-07-27 13:04:48.384
cms38ogf3000104l7utvevswm	cms38gx1f000004jnvhqe1ilw	cms37zki10006hgtd5877avlo	\N	2026-07-27 13:04:51.999
cms38oj4y000204js1on3helm	cms38gx1f000004jnvhqe1ilw	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 13:04:55.522
cms38oluz000004jyplksx1tv	cms38gx1f000004jnvhqe1ilw	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 13:04:59.051
cms38ooh5000204l7b6447s1c	cms38gx1f000004jnvhqe1ilw	cms37zfzn0005hgtd7gza4cvn	\N	2026-07-27 13:05:02.441
cms38oqn2000304l74y5ktx01	cms38gx1f000004jnvhqe1ilw	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 13:05:05.246
cms39d09i000104ld8bghhc0q	cms39cobc000004ldazr6n13i	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 13:23:57.462
cms39d0he000204ldohqq8r59	cms39cobc000004ldazr6n13i	cms37in3h000004i8eoz8ipze	\N	2026-07-27 13:23:57.746
cms39d0p9000304ldile6t5bz	cms39cobc000004ldazr6n13i	cms378xqi0001hgtdr6l6sxef	\N	2026-07-27 13:23:58.029
cms39d0x4000404ld47fvjrx3	cms39cobc000004ldazr6n13i	cms37zki10006hgtd5877avlo	\N	2026-07-27 13:23:58.312
cms39d14z000504ld387dwb1j	cms39cobc000004ldazr6n13i	cms37zfzn0005hgtd7gza4cvn	\N	2026-07-27 13:23:58.595
cms39d1d0000604lddu0oiq5l	cms39cobc000004ldazr6n13i	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 13:23:58.884
cms39d1kv000704ldah5hbnif	cms39cobc000004ldazr6n13i	cms37hxxp000004kv12xpq61b	\N	2026-07-27 13:23:59.167
cms39d1sq000804ldtp503yx6	cms39cobc000004ldazr6n13i	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 13:23:59.45
cms39l24p000604jo9fita8t2	cms397k82000004kyw5azr036	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 13:30:13.129
cms39l2cl000704joj1jox5yu	cms397k82000004kyw5azr036	cms37in3h000004i8eoz8ipze	\N	2026-07-27 13:30:13.413
cms39l2kf000804jo2t2y9dvn	cms397k82000004kyw5azr036	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 13:30:13.695
cms39l2sa000904jofvzd5r1z	cms397k82000004kyw5azr036	cms37zfzn0005hgtd7gza4cvn	\N	2026-07-27 13:30:13.978
cms39l305000a04joujo30pvk	cms397k82000004kyw5azr036	cms37zki10006hgtd5877avlo	\N	2026-07-27 13:30:14.261
cms39l37z000b04jo9ruzvroz	cms397k82000004kyw5azr036	cms378xqi0001hgtdr6l6sxef	\N	2026-07-27 13:30:14.543
cms3bafyi000004l7dgj4dli6	cms3b8xbj000004jm8t35qyuz	cms37zyg50007hgtdu0buusvi	\N	2026-07-27 14:17:57.066
cms3bah1w000504l7c23jmsxd	cms3b8xbj000004jm8t35qyuz	cms37zfzn0005hgtd7gza4cvn	1	2026-07-27 14:17:58.484
cms3bahhm000704l7ictv1jf5	cms3b8xbj000004jm8t35qyuz	cms37hxxp000004kv12xpq61b	1	2026-07-27 14:17:59.05
cms3bagea000204l7m6334lel	cms3b8xbj000004jm8t35qyuz	cms37in3h000004i8eoz8ipze	1	2026-07-27 14:17:57.634
cms3bah9q000604l7e70wuwei	cms3b8xbj000004jm8t35qyuz	cms3808b20008hgtdaxtqowy3	\N	2026-07-27 14:17:58.766
cms3bagm6000304l76ur94wpn	cms3b8xbj000004jm8t35qyuz	cms378xqi0001hgtdr6l6sxef	\N	2026-07-27 14:17:57.918
cms3bagu1000404l77v4lqnsk	cms3b8xbj000004jm8t35qyuz	cms37zki10006hgtd5877avlo	1	2026-07-27 14:17:58.201
cms3bag6e000104l7euq27cjg	cms3b8xbj000004jm8t35qyuz	cms36j9tj000050tdrji7jgzy	\N	2026-07-27 14:17:57.35
\.


--
-- Data for Name: tournaments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournaments (id, name, description, format, status, "startDate", "endDate", "createdById", "createdAt", "updatedAt", surface) FROM stdin;
cms37eo8e0002hgtdbop2o98w	18.07.2026	\N	DOUBLES	COMPLETED	2026-07-18 00:00:00	2026-07-18 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:29:15.95	2026-07-27 12:29:15.95	HARD
cms397k82000004kyw5azr036	18.07.2025	\N	MIXED	COMPLETED	2025-07-18 00:00:00	2025-07-18 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 13:19:43.394	2026-07-27 13:19:43.394	HARD
cms39cobc000004ldazr6n13i	01.10.2025	\N	SINGLES	UPCOMING	2025-10-01 00:00:00	2025-10-01 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 13:23:41.976	2026-07-27 13:27:18.413	HARD
cms38gx1f000004jnvhqe1ilw	01.08.2026	\N	SINGLES	UPCOMING	2026-08-01 00:00:00	2026-08-01 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 12:59:00.291	2026-07-28 06:35:07.568	CLAY
cms3b8xbj000004jm8t35qyuz	Рандомайзер	\N	DOUBLES	UPCOMING	2026-07-27 00:00:00	2026-07-27 00:00:00	cms352tfv0000e0tdmfc0urb6	2026-07-27 14:16:46.255	2026-07-28 06:35:17.153	GRASS
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, role, "createdAt") FROM stdin;
cms352tfv0000e0tdmfc0urb6	Serhii Hilchenko	sdalin777@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocLcfuanMio9VWyqGfu-YaGUzyZ_NqbMmmYp1wAaviGsXHe-3EjQ=s96-c	ADMIN	2026-07-27 11:24:03.595
cms37qbcp000004jldlm5roy0	Margot	mkorobok07@gmail.com	\N	https://lh3.googleusercontent.com/a/ACg8ocJPSzXFcg6hdHql5GfjVpzogbhZ7svNGapc0nzaMivG0c8iFg=s96-c	MEMBER	2026-07-27 12:38:19.129
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (provider, "providerAccountId");


--
-- Name: match_players match_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_pkey PRIMARY KEY (id);


--
-- Name: match_sets match_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT match_sets_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: news_posts news_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT news_posts_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: tournament_participants tournament_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT tournament_participants_pkey PRIMARY KEY (id);


--
-- Name: tournaments tournaments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_tokens verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tokens
    ADD CONSTRAINT verification_tokens_pkey PRIMARY KEY (identifier, token);


--
-- Name: match_players_matchId_side_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_players_matchId_side_playerId_key" ON public.match_players USING btree ("matchId", side, "playerId");


--
-- Name: match_sets_matchId_setNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "match_sets_matchId_setNumber_key" ON public.match_sets USING btree ("matchId", "setNumber");


--
-- Name: players_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX players_email_key ON public.players USING btree (email);


--
-- Name: players_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "players_userId_key" ON public.players USING btree ("userId");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: tournament_participants_tournamentId_playerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tournament_participants_tournamentId_playerId_key" ON public.tournament_participants USING btree ("tournamentId", "playerId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_players match_players_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_players match_players_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT "match_players_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: match_sets match_sets_matchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_sets
    ADD CONSTRAINT "match_sets_matchId_fkey" FOREIGN KEY ("matchId") REFERENCES public.matches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matches matches_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT "matches_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: news_posts news_posts_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_posts
    ADD CONSTRAINT "news_posts_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: players players_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT "players_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.players(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournament_participants tournament_participants_tournamentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_participants
    ADD CONSTRAINT "tournament_participants_tournamentId_fkey" FOREIGN KEY ("tournamentId") REFERENCES public.tournaments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tournaments tournaments_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT "tournaments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 75P2m3Hgdxr0aqtrp2nbAkq4h6NifcGcouRrcJNOUyeTu7pMumki0UzfKB5WZVk

